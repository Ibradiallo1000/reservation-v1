/**
 * Cohérence financière TELIYA — source de vérité et détection d'écarts.
 * Règles : Ventes → createdAt (reservations), Encaissements → cashTransactions filtrées par createdAt + fuseau (pas le champ string paidAt),
 * Ancien KPI réservations `validatedAt` : utilitaire d’audit uniquement ; liquidité et encaissements = ledger (`accounts` + `financialTransactions`).
 */

import { collectionGroup, query, where, getDocs, orderBy, Timestamp, doc, getDoc } from "firebase/firestore";
import { db } from "@/firebaseConfig";
import { normalizeReservation } from "@/lib/normalizeReservation";
import {
  DEFAULT_AGENCY_TIMEZONE,
  getStartOfDayForDate,
  getEndOfDayForDate,
  normalizeDateToYYYYMMDD,
} from "@/shared/date/dateUtilsTz";
import { isSoldReservation, getNetworkCapacityOnly } from "@/modules/compagnie/networkStats/networkStatsService";
import { getUnifiedCommercialActivity } from "@/modules/compagnie/networkStats/activityCore";
import { getCashTransactionsByPaidAtRange, type CashTransactionDocWithId } from "@/modules/compagnie/cash/cashService";
import { CASH_TRANSACTION_STATUS } from "@/modules/compagnie/cash/cashTypes";

export interface FinancialPeriod {
  dateFrom: string;
  dateTo: string;
}

/**
 * Ventes totales (source : réservations vendues, filtrées par createdAt).
 */
export async function getTotalSales(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<{ total: number; tickets: number; reservationCount: number }> {
  const u = await getUnifiedCommercialActivity(companyId, period, { agencyId, timeZone });
  const b = u.billets;
  return {
    total: b.amount,
    tickets: b.tickets,
    reservationCount: b.reservationCount,
  };
}

/** Ventes réseau (réservations vendues, createdAt). Alias explicite pour usage commun. */
export async function getNetworkSales(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<{ total: number; tickets: number; reservationCount: number }> {
  return getTotalSales(companyId, period, agencyId, timeZone);
}

/** Encaissements réseau (cashTransactions status paid, période = createdAt + fuseau). */
export async function getNetworkCash(
  companyId: string,
  period: FinancialPeriod,
  options: { agencyId?: string; includeOrphans?: boolean } = {}
): Promise<TotalCashResult> {
  return getTotalCash(companyId, period, options);
}

/** Réservations avec validatedAt dans la période (hors ledger — audit / ancien reporting). */
export async function getNetworkValidated(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<{ total: number; tickets: number }> {
  return getValidatedRevenue(companyId, period, agencyId, timeZone);
}

/** Billets réseau = somme des places (seatsGo) des réservations vendues (createdAt). */
export async function getNetworkTickets(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<number> {
  const res = await getTotalSales(companyId, period, agencyId, timeZone);
  return res.tickets;
}

/** Remplissage réseau = seatsGo / capacity (0–100 ou null si capacité 0). */
export async function getNetworkOccupancy(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<number | null> {
  const [sales, capacity] = await Promise.all([
    getTotalSales(companyId, period, agencyId, timeZone),
    getNetworkCapacityOnly(companyId, period.dateFrom, period.dateTo),
  ]);
  if (!capacity || capacity <= 0) return null;
  const seatsGo = sales.tickets;
  return Math.round((seatsGo / capacity) * 100);
}

export interface TotalCashResult {
  total: number;
  orphanAmount: number;
  orphanCount: number;
  orphanTransactions: Array<{ id: string; reservationId: string; amount: number; locationId: string }>;
}

/**
 * Encaissements (source : cashTransactions status paid, chargées via createdAt + timeZone, pas le champ string paidAt).
 * Si includeOrphans = false (défaut), n'inclut que les transactions dont la réservation existe et est vendue.
 */
export async function getTotalCash(
  companyId: string,
  period: FinancialPeriod,
  options: { agencyId?: string; includeOrphans?: boolean; timeZone?: string } = {}
): Promise<TotalCashResult> {
  const { agencyId, includeOrphans = false, timeZone = DEFAULT_AGENCY_TIMEZONE } = options;

  const dateFrom = normalizeDateToYYYYMMDD(period.dateFrom);
  const dateTo = normalizeDateToYYYYMMDD(period.dateTo);

  let list: CashTransactionDocWithId[] = await getCashTransactionsByPaidAtRange(
    companyId,
    dateFrom,
    dateTo,
    timeZone
  );

  // Inclut toutes les sources métier (guichet + online). On ne filtre PAS sur sourceType
  // pour ne pas exclure les paiements en ligne, seulement sur le statut PAID.
  const paid = list.filter((t) => (t.status ?? "") === CASH_TRANSACTION_STATUS.PAID);
  const empty: TotalCashResult = { total: 0, orphanAmount: 0, orphanCount: 0, orphanTransactions: [] };
  if (paid.length === 0) return empty;

  const refs = paid.map((t) =>
    doc(db, "companies", companyId, "agences", (t.locationId ?? "") || "unknown", "reservations", t.reservationId)
  );
  const chunks: ReturnType<typeof doc>[][] = [];
  for (let i = 0; i < refs.length; i += 30) {
    chunks.push(refs.slice(i, i + 30));
  }

  const existsAndSold = new Set<string>();
  for (const chunk of chunks) {
    const results = await Promise.all(chunk.map((r) => getDoc(r)));
    results.forEach((snap, idx) => {
      const r = chunk[idx];
      if (!r) return;
      if (snap.exists()) {
        // ⚠️ utiliser normalizeReservation pour toute lecture de réservation
        const raw = snap.data();
        const reservation = normalizeReservation(raw);
        if (isSoldReservation(reservation.payment.status)) existsAndSold.add(r.path);
      }
    });
  }

  let total = 0;
  const orphanTransactions: TotalCashResult["orphanTransactions"] = [];
  paid.forEach((t) => {
    const refPath = `companies/${companyId}/agences/${t.locationId ?? ""}/reservations/${t.reservationId}`;
    const valid = existsAndSold.has(refPath);
    const amount = Number(t.amount) || 0;
    const txId = (t as CashTransactionDocWithId & { id: string }).id;
    if (valid) {
      if (!agencyId || t.locationId === agencyId) total += amount;
    } else {
      orphanTransactions.push({
        id: txId,
        reservationId: t.reservationId,
        amount,
        locationId: t.locationId ?? "",
      });
    }
  });

  const orphanAmount = orphanTransactions.reduce((s, o) => s + o.amount, 0);
  const orphanCount = orphanTransactions.length;
  if (includeOrphans) total += orphanAmount;
  return { total, orphanAmount, orphanCount, orphanTransactions };
}

/**
 * Montants réservations avec validatedAt dans la période (audit — pas la liquidité ledger).
 */
export async function getValidatedRevenue(
  companyId: string,
  period: FinancialPeriod,
  agencyId?: string,
  timeZone: string = DEFAULT_AGENCY_TIMEZONE
): Promise<{ total: number; tickets: number }> {
  const periodStart = getStartOfDayForDate(period.dateFrom, timeZone);
  const periodEnd = getEndOfDayForDate(period.dateTo, timeZone);
  const startTs = Timestamp.fromDate(periodStart);
  const endTs = Timestamp.fromDate(periodEnd);

  const constraints = [
    where("companyId", "==", companyId),
    where("validatedAt", ">=", startTs),
    where("validatedAt", "<=", endTs),
    orderBy("validatedAt", "asc"),
  ];
  if (agencyId) {
    (constraints as unknown[]).unshift(where("agencyId", "==", agencyId));
  }
  const q = query(collectionGroup(db, "reservations"), ...constraints);
  const snap = await getDocs(q);
  let total = 0;
  let tickets = 0; // somme des places (seatsGo)
  snap.docs.forEach((d) => {
    // ⚠️ utiliser normalizeReservation pour toute lecture de réservation
    const raw = d.data();
    const r = normalizeReservation(raw);
    total += r.payment.amount ?? 0;
    tickets += Number(raw.seatsGo ?? raw.seats ?? raw.nbPlaces ?? 1) || 1;
  });
  return { total, tickets };
}

export interface FinancialInconsistencies {
  orphanTransactions: Array<{ id: string; reservationId: string; amount: number; locationId: string }>;
  missingTransactions: Array<{ reservationId: string; agencyId: string; montant: number }>;
  mismatchAmount: number;
  salesTotal: number;
  cashTotal: number;
  cashOrphanAmount: number;
}

/**
 * Détecte les incohérences : transactions orphelines, réservations vendues sans encaissement, écart encaissements > ventes.
 */
export async function detectFinancialInconsistencies(
  companyId: string,
  period: FinancialPeriod
): Promise<FinancialInconsistencies> {
  const periodStart = getStartOfDayForDate(period.dateFrom, DEFAULT_AGENCY_TIMEZONE);
  const periodEnd = getEndOfDayForDate(period.dateTo, DEFAULT_AGENCY_TIMEZONE);
  const startTs = Timestamp.fromDate(periodStart);
  const endTs = Timestamp.fromDate(periodEnd);

  const [salesRes, cashRes, reservationsSnap, cashList] = await Promise.all([
    getTotalSales(companyId, period, undefined, DEFAULT_AGENCY_TIMEZONE),
    getTotalCash(companyId, period, { includeOrphans: false }),
    getDocs(
      query(
        collectionGroup(db, "reservations"),
        where("companyId", "==", companyId),
        where("createdAt", ">=", startTs),
        where("createdAt", "<=", endTs),
        orderBy("createdAt", "asc")
      )
    ),
    getCashTransactionsByPaidAtRange(companyId, period.dateFrom, period.dateTo),
  ]);

  const soldReservations = reservationsSnap.docs.filter((d) => {
    // ⚠️ utiliser normalizeReservation pour toute lecture de réservation
    const raw = d.data();
    const r = normalizeReservation(raw);
    return isSoldReservation(r.payment.status);
  });

  const paidCash = cashList.filter((t) => (t.status ?? "") === CASH_TRANSACTION_STATUS.PAID);
  const reservationIdsWithCash = new Set(
    paidCash.map((t) => `${t.locationId ?? ""}:${t.reservationId}`)
  );
  const missingTransactions: FinancialInconsistencies["missingTransactions"] = [];
  soldReservations.forEach((d) => {
    // ⚠️ utiliser normalizeReservation pour toute lecture de réservation
    const raw = d.data();
    const r = normalizeReservation(raw);
    const agencyId = (r.agencyId ?? raw.agenceId ?? "").toString();
    const reservationId = d.id;
    const key = `${agencyId}:${reservationId}`;
    const montant = r.payment.amount ?? 0;
    if (!reservationIdsWithCash.has(key) && montant > 0) {
      missingTransactions.push({
        reservationId,
        agencyId,
        montant,
      });
    }
  });

  const cashTotalWithOrphans = cashRes.total + cashRes.orphanAmount;
  const mismatchAmount = Math.max(0, cashTotalWithOrphans - salesRes.total);

  // Log de contrôle (temporaire) pour audit: nombre de transactions et montant brut avant filtrage.
  const rawCashTotal = cashList.reduce((s, t) => s + (Number((t as any).amount ?? 0) || 0), 0);
  // eslint-disable-next-line no-console
  console.log("[TELIYA audit] detectFinancialInconsistencies", {
    period,
    salesTotal: salesRes.total,
    cashTotal: cashRes.total,
    cashTxCount: cashList.length,
    paidCashCount: paidCash.length,
    rawCashTotal,
  });

  return {
    orphanTransactions: cashRes.orphanTransactions,
    missingTransactions,
    mismatchAmount: cashRes.orphanAmount + mismatchAmount,
    salesTotal: salesRes.total,
    cashTotal: cashRes.total,
    cashOrphanAmount: cashRes.orphanAmount,
  };
}
