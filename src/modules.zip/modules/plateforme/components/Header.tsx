// src/components/home/Header.tsx
import React, { useEffect, useState } from "react";
import { Sun, Moon, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/firebaseConfig";

const ORANGE = "#FF6600";
const ORANGE_DARK = "#E55400";

type Theme = "light" | "dark" | "system";

const Header: React.FC = () => {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const lang = (i18n.language || "fr").toLowerCase().split("-")[0];
  const isFr = lang === "fr";
  const [logoUrl, setLogoUrl] = useState<string | null>(() => {
    try {
      return localStorage.getItem("teliya:lastLogoUrl");
    } catch {
      return null;
    }
  });
  const [logoLoaded, setLogoLoaded] = useState(false);

  // ---------- GESTION THÈME ----------
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return (localStorage.getItem("teliya:theme") as Theme) || "system";
    } catch {
      return "system";
    }
  });
  const prefersDark =
    typeof window !== "undefined"
      ? window.matchMedia?.("(prefers-color-scheme: dark)").matches
      : false;
  const isDark = theme === "system" ? prefersDark : theme === "dark";

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
    try {
      localStorage.setItem("teliya:theme", theme);
    } catch {}
  }, [theme, isDark]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => {
      if (theme === "system") {
        document.documentElement.classList.toggle("dark", mq.matches);
      }
    };
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, [theme]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // ---------- CHARGEMENT LOGO ----------
  useEffect(() => {
    let cancelled = false;
    getDoc(doc(db, "platform", "settings"))
      .then((snap) => {
        const url = snap.exists() ? (snap.data() as any)?.logoUrl : null;
        if (!cancelled && url) {
          setLogoUrl(url);
          try {
            localStorage.setItem("teliya:lastLogoUrl", url);
          } catch {}
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const goHome = () => navigate("/");
  const goLogin = () => navigate("/login");

  const cycleTheme = () => {
    setTheme((t) =>
      t === "system" ? "dark" : t === "dark" ? "light" : "system"
    );
  };

  return (
    <header className="relative z-50 w-full">
      <div
        className="sticky top-0 z-50 shadow-md border-b border-orange-700/30 transition-all duration-200"
        style={{
          background: `linear-gradient(90deg, ${ORANGE}, ${ORANGE_DARK})`,
          backdropFilter: scrolled ? "saturate(180%) blur(12px)" : undefined,
          WebkitBackdropFilter: scrolled ? "saturate(180%) blur(12px)" : undefined,
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6 py-2.5 flex items-center justify-between gap-4 md:gap-6 text-white">
          {/* Logo + nom */}
          <button
            onClick={goHome}
            className="flex items-center gap-2 select-none"
            aria-label="Accueil Teliya"
          >
            <div className="h-8 w-8 rounded-full bg-white/10 border border-white/20 overflow-hidden shadow-sm grid place-items-center">
              {!logoLoaded && (
                <div className="w-6 h-6 rounded-full bg-white/20 animate-pulse" />
              )}
              <img
                src={logoUrl || "/images/teliya-logo.jpg"}
                alt="Logo Teliya"
                width={40}
                height={40}
                className={`w-full h-full object-contain ${
                  logoLoaded ? "" : "opacity-0"
                }`}
                loading="eager"
                decoding="async"
                onLoad={() => setLogoLoaded(true)}
              />
            </div>
            <span className="text-xl md:text-2xl font-extrabold leading-tight">
              Teliya
            </span>
          </button>

          <div className="flex-1" />

          {/* Langue FR / EN — persistance dans localStorage pour survivre au rechargement */}
          <div className="flex items-center rounded-lg overflow-hidden ring-1 ring-white/20">
            <button
              type="button"
              onClick={() => {
                try {
                  localStorage.setItem("i18nextLng", "fr");
                } catch {}
                i18n.changeLanguage("fr");
              }}
              className={`px-2.5 py-1.5 text-sm font-medium transition ${isFr ? "bg-white/25 text-white" : "text-white/80 hover:bg-white/10 hover:text-white"}`}
              aria-label="Français"
              title="Français"
            >
              FR
            </button>
            <button
              type="button"
              onClick={() => {
                try {
                  localStorage.setItem("i18nextLng", "en");
                } catch {}
                i18n.changeLanguage("en");
              }}
              className={`px-2.5 py-1.5 text-sm font-medium transition ${!isFr ? "bg-white/25 text-white" : "text-white/80 hover:bg-white/10 hover:text-white"}`}
              aria-label="English"
              title="English"
            >
              EN
            </button>
          </div>

          {/* Actions à droite : thème + connexion */}
          <div className="flex items-center gap-2">
            <button
              onClick={cycleTheme}
              className="h-8 w-8 rounded-full grid place-items-center ring-1 ring-white/20 hover:bg-white/10"
              aria-label={t("language")}
              title={
                theme === "system"
                  ? t("themeLight") + " / " + t("themeDark")
                  : isDark
                  ? t("themeDark")
                  : t("themeLight")
              }
            >
              {isDark ? (
                <Moon className="h-5 w-5 text-white" />
              ) : (
                <Sun className="h-5 w-5 text-white" />
              )}
            </button>

            <button
              onClick={goLogin}
              className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-white text-orange-600 hover:scale-105 transition-transform"
              aria-label={t("login")}
              title={t("login")}
            >
              <User className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
