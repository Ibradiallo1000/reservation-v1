// src/pages/RouteResolver.tsx
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState, lazy, Suspense } from "react";
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc,
  onSnapshot,
} from "firebase/firestore";
import { db } from "@/firebaseConfig";
import { getPendingReservation } from "../utils/pendingReservation";

import PageNotFound from "@/shared/ui/PageNotFound";
import ErrorBoundary from "@/shared/core/ErrorBoundary";
import MobileErrorScreen from "@/shared/ui/MobileErrorScreen";
import type { Company } from "@/types/companyTypes";
import { CurrencyProvider } from "@/shared/currency/CurrencyContext";

/* ---------- Lazy pages ---------- */
const PublicCompanyPage = lazy(() => import("../pages/PublicCompanyPage"));
const ResultatsAgencePage = lazy(() => import("../pages/ResultatsAgencePage"));
const ReservationClientPage = lazy(() => import("../pages/ReservationClientPage"));
const ClientMesReservationsPage = lazy(() => import("../pages/ClientMesReservationsPage"));
const ClientMesBilletsPage = lazy(() => import("../pages/ClientMesBilletsPage"));
const MentionsPage = lazy(() => import("../pages/MentionsPage"));
const ConfidentialitePage = lazy(() => import("../pages/ConfidentialitePage"));
const ReceiptEnLignePage = lazy(() => import("../pages/ReceiptEnLignePage"));
const UploadPreuvePage = lazy(() => import("../pages/UploadPreuvePage"));
const PaymentMethodPage = lazy(() => import("../pages/PaymentMethodPage"));
const ReservationDetailsPage = lazy(() => import("../pages/ReservationDetailsPage"));
const AidePage = lazy(() => import("../pages/AidePage"));
const CompanyAboutPage = lazy(() => import("../pages/CompanyAboutPage"));
const LoginPage = lazy(() => import("@/modules/auth/pages/LoginPage"));

import PublicBottomNav from "../components/PublicBottomNav";

/** chemins qui ne doivent jamais être traités comme “slug compagnie” */
/** Domaine public (subdomain = slug.teliya.app). Dev: slug.localhost */
const PUBLIC_APP_DOMAIN = "teliya.app";
const PUBLIC_APP_DOMAIN_LOCALHOST = "localhost";

function getSlugFromSubdomain(): string | null {
  if (typeof window === "undefined") return null;
  const host = window.location.hostname;
  if (host.endsWith("." + PUBLIC_APP_DOMAIN) && host !== PUBLIC_APP_DOMAIN) {
    const sub = host.split(".")[0];
    return sub && sub.length > 0 ? sub : null;
  }
  if (host.endsWith("." + PUBLIC_APP_DOMAIN_LOCALHOST) && host !== PUBLIC_APP_DOMAIN_LOCALHOST) {
    const sub = host.split(".")[0];
    return sub && sub.length > 0 ? sub : null;
  }
  return null;
}

export function isSubdomainMode(): boolean {
  return getSlugFromSubdomain() != null;
}

const RESERVED = new Set([
  "login",
  "register",
  "admin",
  "agence",
  "villes",
  "reservation",
  "contact",
  "compagnie",
]);

/** cache mémoire par session — clé = slug (path ou subdomain) */
const memoryCache = new Map<string, Company>();

/* ---------------------------------------------------------------------------------- */

export default function RouteResolver() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const parts = useMemo(() => pathname.split("/").filter(Boolean), [pathname]);

  /** Slug et segments : sous-domaine (malitrans.teliya.app) ou path (teliya.app/malitrans). */
  const slugFromSubdomain = useMemo(() => getSlugFromSubdomain(), [pathname]);
  const slug = useMemo(() => {
    if (slugFromSubdomain) return slugFromSubdomain;
    return parts[0] ?? null;
  }, [slugFromSubdomain, parts]);
  const subPath = useMemo(() => {
    if (slugFromSubdomain) return parts[0] ?? null;
    return parts[1] ?? null;
  }, [slugFromSubdomain, parts]);
  const thirdSegment = useMemo(() => {
    if (slugFromSubdomain) return parts[1] ?? null;
    return parts[2] ?? null;
  }, [slugFromSubdomain, parts]);

  /** Base path pour les liens : sous-domaine = "" (/, /booking), path = /:slug */
  const pathBase = slugFromSubdomain ? "" : (slug ?? "");

  const [company, setCompany] = useState<Company | null>(null);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  /* Mobile check (stable) */
  const isMobile = useMemo(
    () =>
      typeof window !== "undefined" &&
      (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent
      ) ||
        window.innerWidth <= 768),
    []
  );

  /* Forcer mode jour sur tout le parcours réservation publique (page compagnie → billet). Toujours lisible. */
  useEffect(() => {
    document.documentElement.classList.remove("dark");
    document.documentElement.setAttribute("data-public-booking", "light");
    return () => {
      document.documentElement.removeAttribute("data-public-booking");
    };
  }, []);

  // 1) Résolution du slug -> id de compagnie (avec cache) puis abonnement live
  useEffect(() => {
    let alive = true;
    let unsubscribe: (() => void) | null = null;

    async function resolveAndSubscribe() {
      setLoading(true);
      setError(null);
      setNotFound(false);
      setCompany(null);
      setCompanyId(null);

      // garde-fous
      if (!slug || RESERVED.has(slug.toLowerCase())) {
        if (!alive) return;
        setNotFound(true);
        setLoading(false);
        return;
      }

      // Essai cache mémoire
      const cached = memoryCache.get(slug);
      if (cached) {
        if (!alive) return;
        setCompany(cached);
        setCompanyId(cached.id);
        setLoading(false);
      }

      // Essai sessionStorage
      if (!cached) {
        try {
          const raw = sessionStorage.getItem(`company-${slug}`);
          if (raw) {
            const parsed = JSON.parse(raw) as Company;
            memoryCache.set(slug, parsed);
            if (!alive) return;
            setCompany(parsed);
            setCompanyId(parsed.id);
            setLoading(false);
          }
        } catch {
          /* ignore */
        }
      }

      // Firestore : d’abord par slug, sinon par ID = slug
      try {
        let id: string | null = null;
        if (!cached && !companyId) {
          const bySlugQ = query(collection(db, "companies"), where("slug", "==", slug));
          const bySlugSnap = await getDocs(bySlugQ);
          if (!bySlugSnap.empty) {
            id = bySlugSnap.docs[0].id;
          } else {
            const byIdSnap = await getDoc(doc(db, "companies", slug));
            if (byIdSnap.exists()) id = byIdSnap.id;
          }
        } else {
          id = (cached || company)?.id || companyId;
        }

        if (!id) {
          if (!alive) return;
          setNotFound(true);
          setLoading(false);
          return;
        }

        // Abonnement live → reflète instantanément tout changement (pas besoin de refresh)
        unsubscribe = onSnapshot(
          doc(db, "companies", id),
          (snap) => {
            if (!alive) return;
            if (!snap.exists()) {
              setNotFound(true);
              setCompany(null);
              setCompanyId(null);
              return;
            }
            const normalized = validateCompany(id!, slug!, snap.data());
            setCompanyId(id!);
            setCompany(normalized);
            memoryCache.set(slug!, normalized);
            try {
              sessionStorage.setItem(`company-${slug}`, JSON.stringify(normalized));
            } catch { /* quota / private */ }
            setLoading(false);
          },
          (err) => {
            if (!alive) return;
            if (import.meta.env.DEV) console.debug("RouteResolver onSnapshot error:", err);
            setError(err instanceof Error ? err : new Error("Erreur chargement compagnie"));
            setNotFound(true);
            setLoading(false);
          }
        );
      } catch (e) {
        if (!alive) return;
        if (import.meta.env.DEV) console.debug("RouteResolver Firestore error:", e);
        setError(e instanceof Error ? e : new Error("Erreur chargement compagnie"));
        setNotFound(true);
        setLoading(false);
      }
    }

    resolveAndSubscribe();
    return () => {
      alive = false;
      if (unsubscribe) unsubscribe();
    };
  }, [slug]);

  // Recovery: when on company homepage, if pendingReservation points to a réservation encore en_attente sur Firestore, show modal
  const [recoveryChecked, setRecoveryChecked] = useState(false);
  const [pendingRecovery, setPendingRecovery] = useState<{
    reservationId: string;
    companyId: string;
    agencyId: string;
  } | null>(null);
  const [pendingRecoveryDismissed, setPendingRecoveryDismissed] = useState(false);
  useEffect(() => {
    if (recoveryChecked || loading || notFound || error || subPath !== null || !slug || !company) return;
    let alive = true;
    (async () => {
      try {
        const reservation = await getPendingReservation(db);
        if (!alive) return;
        if (!reservation) {
          setRecoveryChecked(true);
          return;
        }
        const resSlug = String(
          (reservation.companySlug as string) || (reservation.slug as string) || ""
        ).trim();
        if (resSlug && resSlug !== slug) {
          setRecoveryChecked(true);
          return;
        }
        if (String(reservation.companyId) !== company.id) {
          setRecoveryChecked(true);
          return;
        }
        setPendingRecovery({
          reservationId: reservation.id,
          companyId: String(reservation.companyId),
          agencyId: String(reservation.agencyId),
        });
      } finally {
        if (alive) setRecoveryChecked(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, [loading, notFound, error, subPath, slug, company]);

  /* ---------- states ---------- */
  if (loading) return null;
  if (error) return <MobileErrorScreen error={error} />;
  if (notFound || !company) return <PageNotFound />;

  // 2) GARDES FONCTIONNELLES par plan
  // Si la page publique est désactivée (ex: plan Start), on bloque toute la vitrine
  if (company.publicPageEnabled === false) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Site désactivé</h1>
        <p className="text-gray-700 text-center max-w-xl">
          Cette compagnie n’a pas de page publique active avec son plan actuel.
          Veuillez réserver directement au guichet.
        </p>
      </div>
    );
  }

  // Si la réservation en ligne est désactivée, on bloque les écrans de booking
  const blocksOnline = !company.onlineBookingEnabled;
  const isOnlineRoute = subPath === "booking" || subPath === "receipt" || subPath === "confirmation" || subPath === "upload-preuve" || subPath === "payment" || subPath === "reservation" || subPath === "details" || subPath === "retrouver-reservation";
  if (blocksOnline && isOnlineRoute) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <h1 className="text-2xl font-bold text-orange-600 mb-4">Réservation en ligne indisponible</h1>
        <p className="text-gray-700 text-center max-w-xl">
          La réservation en ligne n’est pas incluse dans le plan actuel de cette compagnie.
          Vous pouvez vous rendre au guichet pour effectuer votre réservation.
        </p>
      </div>
    );
  }

  const common = { company, slug: slug ?? undefined, pathBase };
  let content: JSX.Element;

  switch (subPath) {
    case "resultats":
      content = <ResultatsAgencePage {...common} />;
      break;
    case "booking":
      content = <ReservationClientPage />;
      break;
    case "payment":
      content = <PaymentMethodPage slug={slug ?? undefined} />;
      break;
    case "mes-reservations":
      content = <ClientMesReservationsPage />;
      break;
    case "retrouver-reservation":
      content = <ClientMesBilletsPage company={company} />;
      break;
    case "mes-billets":
      content = <ClientMesBilletsPage company={company} />;
      break;
    case "mentions":
      content = <MentionsPage />;
      break;
    case "confidentialite":
      content = <ConfidentialitePage />;
      break;
    case "receipt":
    case "confirmation":
      content = <ReceiptEnLignePage />;
      break;
    case "upload-preuve":
      content = <UploadPreuvePage reservationIdFromPath={thirdSegment ?? undefined} />;
      break;
    case "details":
    case "reservation":
      content = <ReservationDetailsPage />;
      break;
    case "aide":
      content = <AidePage company={company} />;
      break;
    case "a-propos":
      content = <CompanyAboutPage company={company} />;
      break;
    case "login":
      content = <LoginPage company={company} />;
      break;
    case null:
      content = <PublicCompanyPage {...common} isMobile={isMobile} />;
      break;
    default:
      content = <PageNotFound />;
  }

  const showPendingModal = pendingRecovery && slug && !pendingRecoveryDismissed && subPath === null;
  const primaryColor = company?.couleurPrimaire ?? "#3b82f6";

  /** Masquer la barre de navigation du bas pendant le parcours réservation (page plus propre et professionnelle). */
  const isReservationFlow = [
    "booking", "payment", "upload-preuve", "receipt", "confirmation", "details", "reservation", "login",
  ].includes(subPath ?? "");

  return (
    <CurrencyProvider currency={company?.devise}>
      <ErrorBoundary fallback={<MobileErrorScreen />}>
        <Suspense fallback={null}>
          <div className={`public-booking min-h-screen ${isReservationFlow ? "pb-0" : "pb-20 md:pb-0"}`}>
            {content}
            {!isReservationFlow && (
              <PublicBottomNav
                slug={slug}
                primaryColor={company?.couleurPrimaire ?? undefined}
              />
            )}
          </div>
          {/* Modal « Continuer ma réservation » : affichage professionnel, pas dans le header */}
          {showPendingModal && pendingRecovery && (
            <div
              className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
              role="dialog"
              aria-modal="true"
              aria-labelledby="pending-reservation-title"
            >
              <div
                className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 border border-gray-100"
                onClick={(e) => e.stopPropagation()}
              >
                <h2 id="pending-reservation-title" className="text-lg font-semibold text-gray-900 mb-2">
                  Réservation en attente
                </h2>
                <p className="text-sm text-gray-600 mb-6">
                  Vous avez commencé une réservation. Souhaitez-vous continuer pour envoyer votre preuve de paiement ?
                </p>
                <div className="flex flex-col gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      navigate(
                        pathBase
                          ? `/${pathBase}/upload-preuve/${pendingRecovery.reservationId}`
                          : `/upload-preuve/${pendingRecovery.reservationId}`,
                        {
                          replace: true,
                          state: {
                            companyId: pendingRecovery.companyId,
                            agencyId: pendingRecovery.agencyId,
                          },
                        }
                      )
                    }
                    className="w-full rounded-xl py-3 px-4 text-sm font-semibold text-white shadow-sm transition hover:opacity-95"
                    style={{ backgroundColor: primaryColor }}
                  >
                    Continuer ma réservation
                  </button>
                  <button
                    type="button"
                    onClick={() => setPendingRecoveryDismissed(true)}
                    className="w-full rounded-xl py-3 px-4 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 transition"
                  >
                    Plus tard
                  </button>
                </div>
              </div>
            </div>
          )}
        </Suspense>
      </ErrorBoundary>
    </CurrencyProvider>
  );
}

/* ---------- validation légère, évite les undefined ---------- */
function validateCompany(id: string, slug: string, raw: any): Company {
  if (!raw || typeof raw !== "object") throw new Error("Données compagnie invalides");
  return {
    id,
    slug,
    nom: raw.nom ?? "Compagnie",
    themeStyle: raw.themeStyle ?? "clair",
    imagesSlider: Array.isArray(raw.imagesSlider) ? raw.imagesSlider : [],
    footerConfig: {
      customLinks: Array.isArray(raw.footerConfig?.customLinks)
        ? raw.footerConfig.customLinks.map((l: any) => ({
            label: l?.label ?? "Lien",
            url: l?.url ?? "#",
            external: !!l?.external,
          }))
        : [],
    },
    ...raw,
  };
}
