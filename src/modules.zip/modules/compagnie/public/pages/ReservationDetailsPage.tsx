// src/pages/ReservationDetailsPage.tsx
import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  doc, onSnapshot, getDoc, getDocs, collection, query, where,
  updateDoc, serverTimestamp,
} from 'firebase/firestore';
import type { Unsubscribe } from 'firebase/firestore';
import { db } from '@/firebaseConfig';
import { resolveReservationByToken } from '../utils/resolveReservation';
import { saveLocalTicketPointer } from '../utils/localTicketWallet';
import { SectionCard, StatusBadge } from '@/ui';
import {
  ChevronLeft, MapPin, Clock, Calendar, CheckCircle, XCircle, Loader2,
  CreditCard, Ticket, Heart, ChevronRight, Hash, Upload, ShieldCheck, Shield
} from 'lucide-react';
import type { DocumentReference } from 'firebase/firestore';
import TicketOnline from '../components/ticket/TicketOnline';
import ReservationStepHeader from '../components/ReservationStepHeader';
import { useFormatCurrency } from '@/shared/currency/CurrencyContext';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
import { motion, AnimatePresence } from 'framer-motion';
import Confetti from 'react-confetti';
import { useWindowSize } from '@react-hook/window-size';
import { hexToRgba, safeTextColor } from '@/utils/color';
import type { ReservationStatus } from '@/types/reservation';
import { showTicketDirect as showTicketDirectUtil, canViewReceiptPage } from '@/utils/reservationStatusUtils';
import { getDisplayPhone } from '@/utils/phoneUtils';
import { useTranslation } from 'react-i18next';
import { getPublicPathBase } from '../utils/subdomain';
import { ensurePendingOnlinePaymentFromReservation } from '@/services/paymentService';
import { loadPublicCompanyInfoSessionThenFirestore } from '../utils/loadPublicCompanyInfo';
import {
  clearPendingReservation,
  readPendingReservationPointer,
  pendingReservationIdMatches,
} from '../utils/pendingReservation';
import { toast } from 'sonner';
import { resolveAgencyDisplayName } from '../utils/agencyDisplayName';

type PaymentMethod = 'mobile_money' | 'carte_bancaire' | 'espèces' | 'autre' | 'en_ligne' | 'guichet' | string;

interface Reservation {
  id: string;
  nomClient: string;
  telephone: string;
  telephoneOriginal?: string;
  depart: string;
  arrivee: string;
  date: string;
  heure: string;
  montant: number;
  seatsGo: number;
  seatsReturn: number;
  tripType: string;
  referenceCode?: string;

  // === NOUVEAUX STATUTS ===
  statut: ReservationStatus;
  canal?: PaymentMethod;

  // === Autres champs ===
  statutEmbarquement?: string;
  boarded?: boolean;
  boardedAt?: any;
  paidAt?: any;
  validatedAt?: any;
  paymentMethodLabel?: string;
  reason?: string;
  refusalReason?: string;

  companyId: string;
  companySlug: string;
  companyName?: string;
  updatedAt?: string;
  agencyId?: string;
  agencyName?: string;
  agencyNom?: string;
  nomAgence?: string;
  agenceNom?: string;
  publicToken?: string;
}

interface CompanyInfo {
  id: string;
  name: string;
  primaryColor?: string;
  couleurPrimaire?: string;
  logoUrl?: string;
  secondaryColor?: string;
}

/* ====== Mémoire locale ====== */
const STEP_KEY = (slug?: string) => `mb:lastStep:${slug || ''}`;

const clearPending = () => {
  clearPendingReservation();
  try {
    sessionStorage.removeItem('reservationDraft');
    sessionStorage.removeItem('companyInfo');
  } catch {
    /* ignore */
  }
  try {
    const keysToRemove = [
      'currentReservation',
      'lastReservationId',
      'pending_payment',
      'mb_pending',
    ];
    keysToRemove.forEach((key) => {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
    });
  } catch {
    /* ignore */
  }
};

const PAYMENT_METHODS = {
  mobile_money: { text: 'Mobile Money', icon: <CreditCard className="h-4 w-4" /> },
  carte_bancaire: { text: 'Carte bancaire', icon: <CreditCard className="h-4 w-4" /> },
  espèces: { text: 'Espèces', icon: <CreditCard className="h-4 w-4" /> },
  autre: { text: 'Autre moyen', icon: <CreditCard className="h-4 w-4" /> }
} as const;

const getPaymentChip = (label?: string) =>
  label ? { text: label, icon: <CreditCard className="h-4 w-4" /> }
        : { text: 'Non précisé', icon: <CreditCard className="h-4 w-4" /> };

const getDateLocale = (language: string) => (language === 'en' ? 'en-US' : 'fr-FR');

function formatCompactDate(dateString: string, locale: string) {
  return new Date(dateString).toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
}

function formatEmissionDate(locale: string) {
  return new Date().toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
}

/* ====== Configuration des étapes (labels come from t() in component) ====== */
const STEPS_KEYS = [
  { key: 'verification', labelKey: 'reservationStepAwaitingValidation', descKey: 'reservationStepDescVerification', icon: <Upload className="h-4 w-4" />, isFinal: false },
  { key: 'confirme', labelKey: 'reservationStepConfirmed', descKey: 'reservationStepDescConfirmed', icon: <ShieldCheck className="h-4 w-4" />, isFinal: true }
] as const;

const ReservationDetailsPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const language = (i18n.language || 'fr').toLowerCase().startsWith('en') ? 'en' : 'fr';
  const locale = getDateLocale(language);

  const navigate = useNavigate();
  const { slug = '', id } = useParams<{ slug: string; id?: string }>();
  const location = useLocation();
  const money = useFormatCurrency();
  const qs = new URLSearchParams(location.search);
  const token = qs.get('r') || '';
  const reservationRef = useRef<DocumentReference | null>(null);
  const publicTokenRef = useRef<string | null>(null);

  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [agencyName, setAgencyName] = useState<string>('');
  const [agencyLatitude, setAgencyLatitude] = useState<number | null>(null);
  const [agencyLongitude, setAgencyLongitude] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [companyLoadError, setCompanyLoadError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [width, height] = useWindowSize();

  /* Payment / proof section (en_attente_paiement only) */
  const [paymentMethods, setPaymentMethods] = useState<Record<string, { url?: string; logoUrl?: string; ussdPattern?: string; merchantNumber?: string }>>({});
  const [paymentMethodKey, setPaymentMethodKey] = useState<string | null>(null);
  const [proofMessage, setProofMessage] = useState('');
  const [proofUploading, setProofUploading] = useState(false);
  const [proofError, setProofError] = useState<string | null>(null);

  const fallbackColor = '#3b82f6';
  const primaryColor = companyInfo?.couleurPrimaire || companyInfo?.primaryColor || fallbackColor;
  const secondaryColor = companyInfo?.secondaryColor || '#60a5fa';

  // 💾 On mémorise l'écran courant
  useEffect(() => {
    try { localStorage.setItem(STEP_KEY(slug), 'details'); } catch {}
  }, [slug]);

  /** Construit un objet Reservation depuis le snapshot publicReservations (pas d'accès direct à reservations pour le public). */
  const mapPublicSnapshotToReservation = useCallback((data: Record<string, unknown>, reservationId: string): Reservation => {
    const lifecycle = String((data.status ?? '') || '').toLowerCase();
    let normalizedStatus: ReservationStatus = 'en_attente_paiement';
    if (lifecycle === 'en_attente') normalizedStatus = 'en_attente_paiement';
    else if (lifecycle === 'payé' || lifecycle === 'paye') {
      normalizedStatus = data.ticketValidatedAt ? 'confirme' : 'verification';
    } else if (lifecycle === 'annulé' || lifecycle === 'annule') normalizedStatus = 'annule';

    return {
      id: reservationId,
      nomClient: (data.nomClient as string) ?? '',
      telephone: (data.telephone as string) ?? '',
      depart: (data.depart as string) ?? '',
      arrivee: (data.arrivee as string) ?? '',
      date: (data.date as string) ?? '',
      heure: (data.heure as string) ?? '',
      montant: Number(data.montant) ?? 0,
      seatsGo: Number(data.seatsGo) ?? 1,
      seatsReturn: Number(data.seatsReturn) ?? 0,
      tripType: (data.tripType as string) ?? 'aller_simple',
      statut: normalizedStatus,
      canal: (data.canal as string) ?? 'en_ligne',
      referenceCode: data.referenceCode as string | undefined,
      companyId: (data.companyId as string) ?? '',
      companySlug: (data.companySlug as string) ?? '',
      companyName: (data.companyName as string) ?? '',
      agencyId: (data.agencyId as string) ?? '',
      agencyName: (data.agencyName as string | undefined) ??
        ((data.agency as { name?: string } | undefined)?.name) ??
        '',
      agencyNom: (data.agencyNom as string) ?? '',
      nomAgence: (data.nomAgence as string) ?? '',
      agenceNom: (data.agenceNom as string) ?? '',
      updatedAt: (data.updatedAt as any)?.toDate?.()?.toISOString?.() ?? new Date().toISOString(),
    };
  }, []);

  // 🔄 Chargement via publicReservations (snapshot + abonnement par token), pas d'accès direct à reservations pour le public
  useEffect(() => {
    if ((!id && !token) || !slug) { 
      setError('Paramètres manquants'); 
      setLoading(false); 
      return; 
    }
    let unsub: Unsubscribe | undefined;

    (async () => {
      try {
        setLoading(true);
        setError(null);
        setCompanyLoadError(null);
        setCompanyInfo(null);

        let ref: DocumentReference;
        let hardId = id || '';
        let publicToken: string | undefined;
        let snapshot: Record<string, unknown> | undefined;

        if (id) {
          const loc = (location.state || {}) as { companyId?: string; agencyId?: string };
          let companyId = loc.companyId ?? readPendingReservationPointer()?.companyId;
          let agencyId = loc.agencyId ?? readPendingReservationPointer()?.agencyId;
          if (!companyId || !agencyId) {
            const prSnap = await getDoc(doc(db, 'publicReservations', id));
            if (prSnap.exists()) {
              const p = prSnap.data() as Record<string, unknown>;
              companyId = String(p.companyId ?? companyId ?? '');
              agencyId = String(p.agencyId ?? agencyId ?? '');
              publicToken = (p.token ?? p.publicToken) as string | undefined;
            }
          }
          if (!companyId || !agencyId) {
            setError('Réservation introuvable.');
            setLoading(false);
            return;
          }
          ref = doc(db, 'companies', companyId, 'agences', agencyId, 'reservations', id);
          hardId = id;
          const nestedSnap = await getDoc(ref);
          if (nestedSnap.exists()) {
            const nd = nestedSnap.data() as Record<string, unknown>;
            snapshot = {
              ...nd,
              reservationId: id,
              companyId,
              agencyId,
            };
            if (!publicToken && typeof nd.publicToken === 'string') {
              publicToken = nd.publicToken;
            }
          }
        } else if (token) {
          const r = await resolveReservationByToken(slug, token);
          ref = r.ref;
          hardId = r.hardId;
          publicToken = r.publicToken ?? token;
          snapshot = r.snapshot;
        } else {
          setError('Paramètres manquants');
          setLoading(false);
          return;
        }

        reservationRef.current = ref;
        publicTokenRef.current = publicToken ?? null;

        if (snapshot) {
          const resId = (snapshot.reservationId as string) ?? hardId;
          setReservation(mapPublicSnapshotToReservation(snapshot, resId));
        } else if (!publicToken) {
          setError('Réservation introuvable ou expirée. Utilisez le lien de votre billet (mon-billet?r=...).');
        }

        const companyId = ref.path.split('/')[1];
        const agencyId = ref.path.split('/')[3];
        if (publicToken) {
          saveLocalTicketPointer({
            token: publicToken,
            reservationId: hardId,
            companyId,
            agencyId,
            companySlug: slug,
          });
        }
        try {
          const agSnap = await getDoc(doc(db, 'companies', companyId, 'agences', agencyId));
          const ag = agSnap.exists() ? (agSnap.data() as any) : {};
          setAgencyName(resolveAgencyDisplayName(
            snapshot?.agencyNom,
            snapshot?.nomAgence,
            snapshot?.agenceNom,
            snapshot?.agencyName,
            (snapshot?.agency as { name?: string } | undefined)?.name,
            ag?.nomAgence,
            ag?.nom,
            ag?.name,
          ));
          const lat = ag?.latitude != null ? Number(ag.latitude) : null;
          const lng = ag?.longitude != null ? Number(ag.longitude) : null;
          setAgencyLatitude(Number.isFinite(lat) ? lat : null);
          setAgencyLongitude(Number.isFinite(lng) ? lng : null);
        } catch {}
        try {
          const companyRes = await loadPublicCompanyInfoSessionThenFirestore(companyId);
          if (companyRes.ok === false) {
            setCompanyLoadError(companyRes.message);
          } else {
            const i = companyRes.info;
            setCompanyInfo({
              id: i.id,
              name: i.name,
              primaryColor: i.primaryColor,
              secondaryColor: i.secondaryColor,
              couleurPrimaire: i.couleurPrimaire,
              logoUrl: i.logoUrl,
            });
          }
        } catch (e) {
          setCompanyLoadError(
            e instanceof Error ? e.message : 'Erreur lors du chargement des informations compagnie.'
          );
        }

        setLoading(false);

        if (publicToken) {
          unsub = onSnapshot(doc(db, 'publicReservations', publicToken), (snap) => {
            if (!snap.exists()) return;
            const data = snap.data() as Record<string, unknown>;
            const resId = (data.reservationId as string) ?? hardId;
            setReservation(mapPublicSnapshotToReservation(data, resId));
            const pend = readPendingReservationPointer();
            const st = String(data.status ?? '').toLowerCase();
            if (
              (st === 'annulé' || st === 'annule' || data.ticketValidatedAt) &&
              pendingReservationIdMatches(pend, resId)
            ) {
              clearPending();
            }
          }, (e) => {
            console.error('publicReservations onSnapshot:', e);
          });
        } else if (id && reservationRef.current) {
          unsub = onSnapshot(reservationRef.current, (snap) => {
            if (!snap.exists()) return;
            const data = snap.data() as Record<string, unknown>;
            setReservation(mapPublicSnapshotToReservation(data, snap.id));
            const pend = readPendingReservationPointer();
            const st = String(data.status ?? '').toLowerCase();
            if (
              (st === 'annulé' || st === 'annule' || data.ticketValidatedAt) &&
              pendingReservationIdMatches(pend, snap.id)
            ) {
              clearPending();
            }
          });
        }

        if (!id && hardId) {
          const slugToUse = (snapshot?.companySlug as string) || slug;
          window.history.replaceState({}, '', `/${slugToUse}/reservation/${hardId}`);
        }
      } catch (e: any) {
        console.error('❌ Erreur générale:', e);
        clearPending();
        setError(e?.message || 'Impossible de localiser la réservation'); 
        setLoading(false);
      }
    })();

    return () => { unsub?.(); };
  }, [id, token, slug, location.state, mapPublicSnapshotToReservation]);

  useEffect(() => {
    const inlineAgencyName = resolveAgencyDisplayName(
      reservation?.agencyNom,
      reservation?.nomAgence,
      reservation?.agenceNom,
      reservation?.agencyName,
    );
    if (inlineAgencyName) setAgencyName(String(inlineAgencyName).trim());
  }, [
    reservation?.agencyNom,
    reservation?.nomAgence,
    reservation?.agenceNom,
    reservation?.agencyName,
  ]);

  // 🎉 Confetti pour paiement confirmé
  useEffect(() => {
    if (reservation?.statut === 'confirme') {
      const k = `celebrated-${reservation.id}`;
      if (!localStorage.getItem(k)) {
        setShowConfetti(true);
        localStorage.setItem(k, 'true');
        const t = setTimeout(() => setShowConfetti(false), 5000);
        return () => clearTimeout(t);
      }
    }
  }, [reservation?.statut, reservation?.id]);

  /* Chargement des moyens de paiement (section preuve : en attente de paiement en ligne) */
  useEffect(() => {
    if (!reservation?.companyId || reservation?.statut !== 'en_attente_paiement') return;
    let cancelled = false;
    (async () => {
      try {
        const pmSnap = await getDocs(
          query(collection(db, 'paymentMethods'), where('companyId', '==', reservation.companyId))
        );
        if (cancelled) return;
        const pms: Record<string, { url?: string; logoUrl?: string; ussdPattern?: string; merchantNumber?: string }> = {};
        pmSnap.forEach((ds) => {
          const d = ds.data() as any;
          if (d.name) pms[d.name] = {
            url: d.defaultPaymentUrl || '',
            logoUrl: d.logoUrl || '',
            ussdPattern: d.ussdPattern || '',
            merchantNumber: d.merchantNumber || '',
          };
        });
        setPaymentMethods(pms);
      } catch {}
    })();
    return () => { cancelled = true; };
  }, [reservation?.companyId, reservation?.statut]);

  const submitProof = useCallback(async () => {
    const ref = reservationRef.current;
    if (!ref || !reservation) return;
    if (!paymentMethodKey) {
      setProofError('Sélectionnez un moyen de paiement');
      return;
    }
    if ((proofMessage || '').trim().length < 4) {
      setProofError('Indiquez la référence reçue (au moins 4 caractères)');
      return;
    }
    if (reservation.statut !== 'en_attente_paiement') {
      setProofError('Cette réservation a expiré ou a déjà été traitée.');
      return;
    }
    setProofUploading(true);
    setProofError(null);
    try {
      const inputReference = (proofMessage || '').trim();
      await updateDoc(ref, {
        status: 'preuve_recue',
        statut: 'preuve_recue',
        paymentReference: inputReference,
        proofSubmittedAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      const tok = publicTokenRef.current;
      if (tok) {
        await updateDoc(doc(db, 'publicReservations', tok), {
          status: 'preuve_recue',
          paymentReference: inputReference,
          updatedAt: serverTimestamp(),
        });
      }
      const pathParts = ref.path.split('/');
      const companyIdResolved = reservation.companyId || pathParts[1] || '';
      const agencyIdResolved = reservation.agencyId || pathParts[3] || '';
      const ensure = await ensurePendingOnlinePaymentFromReservation({
        companyId: companyIdResolved,
        agencyId: agencyIdResolved,
        reservationId: reservation.id,
        montant: Number(reservation.montant) || 0,
        paymentMethodLabel: paymentMethodKey,
      });
      if (!ensure.ok) {
        console.warn('[ReservationDetailsPage] ensurePendingOnlinePaymentFromReservation', ensure.error);
        toast.error('Preuve enregistrée, mais la caisse digitale n’a pas reçu l’entrée paiement.', {
          description: ensure.error ?? 'Vérifiez les règles/index Firestore « payments » et redéployez l’app.',
          duration: 12_000,
        });
      }
      clearPending();
      setProofMessage('');
      setProofError(null);
    } catch (e: any) {
      setProofError(e?.message || "L'envoi n'a pas abouti. Réessayez.");
    } finally {
      setProofUploading(false);
    }
  }, [reservation, paymentMethodKey, proofMessage]);

  /* ===== Décision d'affichage (utilitaire partagé) ===== */
  const isTicketAvailable = showTicketDirectUtil(reservation);
  const canViewReceipt = canViewReceiptPage(reservation);
  const canal = String(reservation?.canal || '').toLowerCase();

  /* ===== Configuration de la timeline ===== */
  const currentStepIndex = reservation 
    ? Math.max(0, STEPS_KEYS.findIndex(step => step.key === reservation.statut))
    : -1;

  const stepDescriptions: Record<string, string> = {
    en_attente: t('reservationStepDescPending'),
    verification: t('reservationStepDescVerification'),
    confirme: t('reservationStepDescConfirmed'),
    refuse: t('reservationStepDescRefused'),
    annule: t('reservationStepDescCancelled')
  };

  /* 🚀 Redirection automatique si billet disponible (URL seule, pas de state) */
  useEffect(() => {
    if (!isTicketAvailable || !reservation) return;
    const currentPath = window.location.pathname;
    const slugToUse = reservation.companySlug || slug;
    const pathBase = getPublicPathBase(slugToUse);
    const targetPath = pathBase ? `/${pathBase}/receipt/${reservation.id}` : `/receipt/${reservation.id}`;
    if (currentPath !== targetPath) {
      navigate(targetPath, { replace: true });
    }
  }, [isTicketAvailable, reservation, slug, navigate]);

  // Méthode de paiement affichée
  const paymentLabel =
    canal === 'guichet'
      ? 'Espèces'
      : (reservation?.paymentMethodLabel ||
         (reservation?.canal && reservation.canal !== 'en_ligne' 
           ? String(reservation.canal).replace(/_/g,' ') 
           : 'En ligne'));

  const paymentChip = getPaymentChip(paymentLabel);
  const lastUpdated = reservation?.updatedAt && !isNaN(new Date(reservation.updatedAt).getTime())
    ? new Date(reservation.updatedAt).toLocaleString('fr-FR', { 
        day: 'numeric', 
        month: 'short', 
        hour: '2-digit', 
        minute: '2-digit' 
      })
    : null;

  // 🔴 CORRECTION : Gestion du bouton "Retour" — toujours vers l'accueil compagnie (évite 404 en sous-domaine)
  const handleGoBack = () => {
    clearPending();
    const slugToUse = reservation?.companySlug || slug;
    const pathBase = getPublicPathBase(slugToUse);
    navigate(pathBase ? `/${pathBase}` : '/', { replace: false });
  };

  // 🔴 CORRECTION : Gestion du bouton "Nouvelle réservation"
  const handleNewReservation = () => {
    // Nettoyage complet avant nouvelle réservation
    clearPending();
    const slugToUse = reservation?.companySlug || slug;
    const pathBase = getPublicPathBase(slugToUse);
    navigate(pathBase ? `/${pathBase}` : '/', { replace: true });
  };

  // ===== RENDER =====

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#f8fafc' }}>
        <div className="flex flex-col items-center space-y-3">
          <Loader2 className="h-8 w-8 animate-spin" style={{ color: primaryColor }} />
          <p className="text-gray-700 text-sm">Chargement de votre réservation...</p>
        </div>
      </div>
    );
  }

  if (error || !reservation) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#f8fafc' }}>
        <SectionCard title="Réservation introuvable" icon={XCircle} className="max-w-md w-full shadow-md">
          <p className="text-gray-600 mb-5 text-center">
            {error || 'Cette réservation a expiré ou a été supprimée.'}
          </p>
          <div className="space-y-2">
            <button 
              onClick={handleNewReservation}
              className="w-full px-5 py-3 rounded-lg text-sm font-semibold shadow-sm"
              style={{ 
                backgroundColor: primaryColor, 
                color: safeTextColor(primaryColor) 
              }}
            >
              Créer une nouvelle réservation
            </button>
            <button 
              onClick={handleGoBack}
              className="w-full px-5 py-2.5 rounded-lg text-sm font-medium text-gray-600 border border-gray-200 hover:bg-gray-50 transition-colors"
            >
              Retour
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-4 pt-4 border-t border-gray-200">
            💡 Conseil : Videz le cache de votre navigateur si le problème persiste.
          </p>
        </SectionCard>
      </div>
    );
  }

  if (companyLoadError || !companyInfo) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#f8fafc' }}>
        <SectionCard title="Informations compagnie indisponibles" icon={XCircle} className="max-w-md w-full shadow-md">
          <p className="text-gray-600 mb-5 text-center">
            {companyLoadError ||
              'Impossible de charger les informations de la compagnie. Réessayez ou reprenez depuis l’accueil.'}
          </p>
          <div className="space-y-2">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full px-5 py-3 rounded-lg text-sm font-semibold shadow-sm bg-blue-600 text-white hover:bg-blue-700"
            >
              Réessayer
            </button>
            <button
              type="button"
              onClick={handleGoBack}
              className="w-full px-5 py-2.5 rounded-lg text-sm font-medium text-gray-600 border border-gray-200 hover:bg-gray-50 transition-colors"
            >
              Retour
            </button>
          </div>
        </SectionCard>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-32" style={{ background: 'linear-gradient(180deg, #f8fafc, #ffffff)' }}>
      <AnimatePresence>
        {reservation.statut === 'confirme' && (
          <Confetti
            width={width}
            height={height}
            recycle={false}
            numberOfPieces={200}
            colors={[primaryColor, secondaryColor, '#ffffff']}
          />
        )}
      </AnimatePresence>

      <ReservationStepHeader
        onBack={handleGoBack}
        primaryColor={primaryColor}
        secondaryColor={secondaryColor}
        title="Détails de réservation"
        logoUrl={companyInfo?.logoUrl}
      />

      <main className="max-w-md mx-auto px-4 py-5 space-y-5">
        {/* Étapes – visibles uniquement pour réservations en ligne */}
        {reservation.canal === 'en_ligne' && reservation.statut !== 'refuse' && reservation.statut !== 'annule' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
          >
            <SectionCard title={t('reservationPaymentTracking')} icon={Upload} right={lastUpdated ? <span className="text-xs text-gray-500">{lastUpdated}</span> : undefined} className="shadow-md">

            <div className="relative">
              <div className="absolute top-3 left-0 right-0 h-1 bg-gray-200 rounded-full z-0" />
              <motion.div
                className="absolute top-3 left-0 h-1 rounded-full z-0"
                style={{ backgroundColor: primaryColor }}
                initial={{ width: 0 }}
                animate={{ 
                  width: `${Math.max(0, ((currentStepIndex + 1) / STEPS_KEYS.length) * 100)}%` 
                }}
                transition={{ type: 'spring', stiffness: 120, damping: 18 }}
              />
              <div className="relative z-10 flex justify-between">
                {STEPS_KEYS.map((step, idx) => {
                  const isActive = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex && reservation.statut !== 'confirme';
                  const IconComponent = step.icon;

                  return (
                    <div key={step.key} className="flex flex-col items-center w-1/2">
                      <div className="relative mb-1">
                        <div
                          className="h-6 w-6 rounded-full flex items-center justify-center"
                          style={{
                            backgroundColor: isActive ? primaryColor : '#e5e7eb',
                            color: isActive ? safeTextColor(primaryColor) : '#6b7280',
                            border: isCurrent ? `2px solid ${safeTextColor(primaryColor)}` : 'none'
                          }}
                        >
                          {idx < currentStepIndex
                            ? <CheckCircle className="h-3.5 w-3.5" />
                            : isCurrent && reservation.statut === 'verification'
                              ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              : IconComponent}
                        </div>
                        {isCurrent && reservation.statut === 'verification' && (
                          <span
                            className="absolute inset-0 rounded-full"
                            style={{
                              border: `2px solid ${primaryColor}`,
                              opacity: 0.45,
                              animation: 'pingStep 1.2s cubic-bezier(0,0,0.2,1) infinite'
                            }}
                          />
                        )}
                      </div>
                      <span className={`text-xs text-center ${isActive ? 'font-medium text-gray-900' : 'text-gray-500'}`}>
                        {t(step.labelKey)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
            </SectionCard>
          </motion.div>
        )}

        {/* Bandeau statut + références */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <SectionCard title={t('reservationStatus')} icon={CheckCircle} className="shadow-md">
          <div className="flex items-start gap-3">
          <div
            className="p-2 rounded-lg flex-shrink-0"
            style={{
              backgroundColor: '#ffffff',
              color:
                reservation.statut === 'confirme'
                  ? '#059669'
                  : reservation.statut === 'verification'
                  ? '#6d28d9'
                  : reservation.statut === 'refuse'
                  ? '#dc2626'
                  : reservation.statut === 'annule'
                  ? '#6b7280'
                  : primaryColor
            }}
          >
            {reservation.statut === 'confirme' ? <CheckCircle className="h-4 w-4" /> :
             reservation.statut === 'refuse' || reservation.statut === 'annule' ? <XCircle className="h-4 w-4" /> :
             reservation.statut === 'verification' ? <Upload className="h-4 w-4" /> :
             <Loader2 className="h-4 w-4 animate-spin" />}
          </div>
          <div className="flex-1">
            <p className="font-medium text-sm mb-1">
              {reservation.statut === 'confirme' ? t('reservationStatusConfirmed') :
               reservation.statut === 'refuse' ? t('reservationStatusRefused') :
               reservation.statut === 'annule' ? t('reservationStatusCancelled') :
               reservation.statut === 'verification' ? t('reservationStatusValidation') :
               t('reservationStatusAwaitingPayment')}
            </p>
            <p className="text-xs text-gray-600">
              {stepDescriptions[reservation.statut] || stepDescriptions.en_attente}
              {(reservation.refusalReason || reservation.reason) && reservation.statut === 'refuse' && (
                <span className="block mt-1 text-red-600 font-medium">
                  {t('reservationReason')} : {reservation.refusalReason || reservation.reason}
                </span>
              )}
            </p>

            {reservation.referenceCode && (
              <p className="mt-2 text-xs text-gray-700 flex items-center gap-1">
                <Hash className="h-3 w-3" /> 
                <span className="font-semibold">N°</span> {reservation.referenceCode}
              </p>
            )}
            {agencyName && (
              <p className="text-xs text-gray-600 mt-1 flex items-center gap-1">
                <MapPin className="h-3 w-3" /> 
                <span className="font-semibold">Agence :</span> {agencyName}
              </p>
            )}
            {reservation.statut === 'confirme' && (
              <p className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-500 flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-gray-400" />
                Réservation confirmée · Support disponible
              </p>
            )}
          </div>
          </div>
          </SectionCard>
        </motion.div>

        {/* Section paiement / justificatif (en attente paiement en ligne) */}
        {reservation.canal === 'en_ligne' && reservation.statut === 'en_attente_paiement' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
            <SectionCard title="Justificatif de paiement" icon={CreditCard} className="shadow-md">
              <p className="text-sm text-gray-600 mb-3">Choisissez un moyen de paiement, effectuez le paiement, puis indiquez la référence reçue.</p>
              {proofError && (
                <div className="mb-3 p-2 rounded-lg bg-red-50 text-red-800 text-sm">{proofError}</div>
              )}
              <div className="flex flex-wrap gap-2 mb-3">
                {Object.entries(paymentMethods).map(([key, method]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setPaymentMethodKey(key);
                      if (method.url) {
                        try { new URL(method.url); window.open(method.url, '_blank', 'noopener,noreferrer'); } catch {}
                      } else if (method.ussdPattern && method.merchantNumber) {
                        const ussd = method.ussdPattern.replace('MERCHANT', method.merchantNumber || '').replace('AMOUNT', String(reservation.montant || 0));
                        window.location.href = `tel:${encodeURIComponent(ussd)}`;
                      }
                    }}
                    className={`px-3 py-2 rounded-lg text-sm font-medium border transition-colors ${
                      paymentMethodKey === key ? 'border-gray-400 bg-gray-100' : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    {key}
                  </button>
                ))}
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-medium text-gray-700">Référence reçue (SMS / reçu)</label>
                <input
                  type="text"
                  value={proofMessage}
                  onChange={(e) => setProofMessage(e.target.value)}
                  placeholder="Ex. 12345678"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-900 placeholder-gray-500"
                />
                <button
                  type="button"
                  onClick={submitProof}
                  disabled={proofUploading || !paymentMethodKey || proofMessage.trim().length < 4}
                  className="w-full py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-50"
                  style={{ backgroundColor: primaryColor, color: safeTextColor(primaryColor) }}
                >
                  {proofUploading ? 'Envoi…' : 'Envoyer le justificatif'}
                </button>
              </div>
              <p className="mt-3 text-xs text-gray-500 flex items-center gap-1">
                <Shield className="h-3.5 w-3.5" /> Paiement sécurisé · Support disponible
              </p>
            </SectionCard>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.22 }}
        >
          <SectionCard title="Détails du voyage" icon={Ticket} className="shadow-md">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-1.5 rounded-lg bg-gray-100 flex-shrink-0">
                <MapPin className="h-4 w-4 text-gray-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Itinéraire</p>
                <p className="text-sm font-medium text-gray-900">
                  {reservation.depart} <ChevronRight className="inline h-3 w-3 mx-1 text-gray-400" /> {reservation.arrivee}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-gray-100 flex-shrink-0">
                  <Calendar className="h-4 w-4 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Date</p>
                  <p className="text-sm font-medium text-gray-900">
                    {formatCompactDate(reservation.date, locale)}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-gray-100 flex-shrink-0">
                  <Clock className="h-4 w-4 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Heure</p>
                  <p className="text-sm font-medium text-gray-900">{reservation.heure}</p>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-1.5 rounded-lg bg-gray-100 flex-shrink-0">
                <CreditCard className="h-4 w-4 text-gray-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 mb-1">Paiement</p>
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium text-gray-900">
                    {money(reservation.montant)}
                  </p>
                  <StatusBadge status="neutral">{paymentChip.text}</StatusBadge>
                </div>
              </div>
            </div>

            {reservation.tripType === 'aller-retour' && (
              <div className="text-xs text-gray-600 bg-gray-50 px-3 py-2 rounded-lg border border-gray-200">
                <p className="font-medium text-gray-700 mb-1">Aller-retour</p>
                <div className="flex justify-between">
                  <span>Aller: {reservation.seatsGo} place(s)</span>
                  <span>Retour: {reservation.seatsReturn} place(s)</span>
                </div>
              </div>
            )}
          </div>
          </SectionCard>
        </motion.div>

        {/* Billet toujours visible (QR actif ou "En attente de validation") */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }}>
          <SectionCard title="Votre billet" icon={Ticket} className="shadow-md">
            <TicketOnline
              companyName={companyInfo?.name || reservation.companyName || 'Compagnie'}
              logoUrl={companyInfo?.logoUrl}
              primaryColor={primaryColor}
              secondaryColor={secondaryColor}
              agencyName={agencyName}
              receiptNumber={reservation.referenceCode || reservation.id}
              statut={reservation.statut}
              nomClient={reservation.nomClient}
              telephone={getDisplayPhone(reservation)}
              depart={reservation.depart}
              arrivee={reservation.arrivee}
              date={reservation.date}
              heure={reservation.heure}
              seats={reservation.seatsGo ?? 1}
              canal={reservation.canal}
              montant={reservation.montant}
              qrValue={`${typeof window !== 'undefined' ? window.location.origin : ''}/r/${encodeURIComponent(reservation.referenceCode || reservation.id)}`}
              emissionDate={formatEmissionDate(locale)}
              paymentMethod={paymentLabel}
              agencyLatitude={agencyLatitude}
              agencyLongitude={agencyLongitude}
            />
          </SectionCard>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ delay: 0.35 }} 
          className="text-center pt-4"
        >
          <div className="flex items-center justify-center gap-1 text-sm text-gray-600">
            <Heart className="h-3.5 w-3.5 text-rose-400 fill-rose-400" />
            <span>{t('reservationThanksTrust')}</span>
          </div>
          <p className="text-sm font-medium mt-1" style={{ color: primaryColor }}>
            {reservation.companyName || companyInfo?.name || t('reservationYourCompany')}
          </p>
        </motion.div>
      </main>

      {/* CTA bas */}
      <div
        className="fixed bottom-0 left-0 w-full z-40 px-4 py-3 shadow-md border-t"
        style={{ backgroundColor: '#ffffff', borderColor: 'rgba(0,0,0,0.06)' }}
      >
        <div className="max-w-md mx-auto">
          {reservation.statut !== 'refuse' && reservation.statut !== 'annule' ? (
            <>
              <button
                onClick={() => {
                  const slugToUse = reservation.companySlug || slug;
                  const pathBase = getPublicPathBase(slugToUse);
                  navigate(pathBase ? `/${pathBase}/receipt/${reservation.id}` : `/receipt/${reservation.id}`, { replace: false });
                }}
                className={`w-full py-3 rounded-lg text-sm font-medium flex items-center justify-center gap-2 shadow-sm transition-all ${
                  canViewReceipt ? 'hover:opacity-95' : 'opacity-70 cursor-not-allowed'
                }`}
                style={{
                  background: canViewReceipt
                    ? `linear-gradient(135deg, ${primaryColor}, ${secondaryColor})`
                    : `linear-gradient(135deg, ${hexToRgba(primaryColor,0.5)}, ${hexToRgba(secondaryColor,0.5)})`,
                  color: safeTextColor(primaryColor)
                }}
                disabled={!canViewReceipt}
              >
                <CheckCircle className="h-4 w-4" />
                {isTicketAvailable
                  ? t('reservationViewTicket')
                  : canViewReceipt
                    ? t('reservationViewReceipt')
                    : t('reservationWaitingConfirmation')
                }
              </button>
              
              <button
                onClick={handleNewReservation}
                className="w-full mt-3 py-2.5 rounded-lg text-sm font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
              >
                {t('reservationNewReservation')}
              </button>
            </>
          ) : (
            <div className="space-y-3">
              <div className="text-center py-3 text-gray-600">
                <p className="font-medium mb-1">
                  {reservation.statut === 'refuse' ? t('reservationRefusedTitle') : t('reservationCancelledTitle')}
                </p>
                <p className="text-sm">
                  {reservation.statut === 'refuse' 
                    ? t('reservationContactCompany') 
                    : t('reservationCreateNewDesc')}
                </p>
              </div>
              
              <button
                onClick={handleNewReservation}
                className="w-full py-3 rounded-lg text-sm font-medium shadow-sm"
                style={{ 
                  backgroundColor: primaryColor, 
                  color: safeTextColor(primaryColor) 
                }}
              >
                {t('reservationNewReservation')}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* keyframes pour l'anneau "ping" */}
      <style>
        {`
          @keyframes pingStep {
            0% { transform: scale(1); opacity: .45; }
            80% { transform: scale(1.75); opacity: 0; }
            100% { transform: scale(1.75); opacity: 0; }
          }
        `}
      </style>
    </div>
  );
};

export default ReservationDetailsPage;
