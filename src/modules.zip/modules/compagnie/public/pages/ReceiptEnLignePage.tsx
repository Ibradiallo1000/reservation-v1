// src/pages/ReceiptEnLignePage.tsx

import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
  useMemo
} from 'react';

import {
  useParams,
  useNavigate,
  useLocation
} from 'react-router-dom';

import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '@/firebaseConfig';
import {
  readPendingReservationPointer,
  reservationNestedRef,
} from '@/modules/compagnie/public/utils/pendingReservation';
import { Download, Printer, Home } from 'lucide-react';
import ReservationStepHeader from '@/modules/compagnie/public/components/ReservationStepHeader';
import html2pdf from 'html2pdf.js';
import html2canvas from 'html2canvas';
import { safeTextColor } from '@/utils/color';
import { format, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useOnlineStatus } from '@/shared/hooks/useOnlineStatus';
import { PageLoadingState } from '@/shared/ui/PageStates';

import TicketOnline from '@/modules/compagnie/public/components/ticket/TicketOnline';
import { getEffectiveStatut } from '@/utils/reservationStatusUtils';
import { getDisplayPhone } from '@/utils/phoneUtils';
import type { ReservationStatus } from '@/types/reservation';
import { getSlugFromSubdomain } from '@/modules/compagnie/public/utils/subdomain';
import { ensurePendingOnlinePaymentFromReservation } from '@/services/paymentService';
import { loadPublicCompanyInfoSessionThenFirestore } from '@/modules/compagnie/public/utils/loadPublicCompanyInfo';
import { resolveAgencyDisplayName } from '@/modules/compagnie/public/utils/agencyDisplayName';

interface Reservation {
  id: string;
  nomClient: string;
  telephone: string;
  depart: string;
  arrivee: string;
  date: string;
  heure: string;
  montant: number;
  referenceCode?: string;
  companyId: string;
  companySlug: string;
  agencyId?: string;
  agencyName?: string;
  nomAgence?: string;
  agencyNom?: string;
  agenceNom?: string;
  statut?: ReservationStatus;
  canal?: string;
  seatsGo: number;
  createdAt?: any;
  modePaiement?: string;
  preuveVia?: string;
  remboursement?: { mode?: string };
}

interface CompanyInfo {
  id: string;
  name: string;
  couleurPrimaire?: string;
  couleurSecondaire?: string;
  logoUrl?: string;
  slug?: string;
  telephone?: string;
}

function mapPublicReceiptReservation(
  data: Record<string, unknown>,
  fallbackId: string,
  fallbackCompanyId?: string,
  fallbackAgencyId?: string,
): Reservation {
  const rawStatus = String(data.status ?? data.statut ?? '').toLowerCase();
  const statut: ReservationStatus =
    rawStatus === 'confirme'
      ? 'confirme'
      : rawStatus === 'payé' || rawStatus === 'paye'
        ? 'paye'
        : rawStatus === 'preuve_recue'
          ? 'preuve_recue'
          : rawStatus === 'verification'
            ? 'verification'
            : rawStatus === 'annulé' || rawStatus === 'annule'
              ? 'annule'
              : rawStatus === 'refuse' || rawStatus === 'refusé'
                ? 'refuse'
                : 'en_attente_paiement';

  return {
    id: String(data.reservationId ?? fallbackId),
    companyId: String(data.companyId ?? fallbackCompanyId ?? ''),
    agencyId: String(data.agencyId ?? fallbackAgencyId ?? ''),
    companySlug: String(data.companySlug ?? data.slug ?? ''),
    nomClient: String(data.nomClient ?? data.clientNom ?? ''),
    telephone: getDisplayPhone(data),
    depart: String(data.depart ?? data.departure ?? ''),
    arrivee: String(data.arrivee ?? data.arrival ?? ''),
    date: String(data.date ?? ''),
    heure: String(data.heure ?? ''),
    montant: Number(data.montant ?? data.montant_total ?? 0),
    referenceCode: data.referenceCode as string | undefined,
    statut,
    canal: String(data.canal ?? 'en_ligne'),
    seatsGo: Number(data.seatsGo ?? data.nombre_places ?? data.seats ?? 1),
    createdAt: data.createdAt,
    agencyName: data.agencyName as string | undefined,
    nomAgence: data.nomAgence as string | undefined,
    agencyNom: data.agencyNom as string | undefined,
    agenceNom: data.agenceNom as string | undefined,
    modePaiement: data.modePaiement as string | undefined,
    preuveVia: data.preuveVia as string | undefined,
    remboursement: data.remboursement as { mode?: string } | undefined,
  };
}

const ReceiptEnLignePage: React.FC = () => {
  const params = useParams<{ slug?: string; id?: string }>();
  const location = useLocation();
  const navigate = useNavigate();

  // Sous-domaine (prod) : /receipt/:id → pathParts = ['receipt', id]. Path (dev) : /:slug/receipt/:id → pathParts = [slug, 'receipt', id].
  const pathParts = useMemo(() => location.pathname.split('/').filter(Boolean), [location.pathname]);
  const slugFromSub = getSlugFromSubdomain();
  const id =
    params.id ??
    (pathParts[0] === 'receipt' ? pathParts[1] : pathParts[1] === 'receipt' ? pathParts[2] : undefined);
  const slug = slugFromSub ?? params.slug ?? (pathParts[0] !== 'receipt' ? pathParts[0] : '') ?? '';
  /** Sous-domaine : accueil = /. Sinon accueil = /:slug (évite 404 sur "Retour") */
  const homePath = slugFromSub ? '/' : (slug ? `/${slug}` : '/');

  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [companyLoadError, setCompanyLoadError] = useState<string>('');
  const [agencyName, setAgencyName] = useState<string>('');
  const [agencyLatitude, setAgencyLatitude] = useState<number | null>(null);
  const [agencyLongitude, setAgencyLongitude] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [notFound, setNotFound] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<string>('');
  const [reloadKey, setReloadKey] = useState(0);
  const isOnline = useOnlineStatus();

  const receiptRef = useRef<HTMLDivElement>(null);

  const receiptState = (location.state || {}) as { companyId?: string; agencyId?: string };

  const primaryColor = companyInfo?.couleurPrimaire ?? '#8b3a2f';
  const secondaryColor = companyInfo?.couleurSecondaire ?? '#f59e0b';
  const textColor = safeTextColor(primaryColor);

  /* LOAD RESERVATION — onSnapshot for real-time update when company validates (statut → confirme) */
  useEffect(() => {
    if (!id || !slug) {
      setLoading(false);
      setNotFound(!id);
      return;
    }

    let unsubPublic: (() => void) | undefined;
    let unsubNested: (() => void) | undefined;
    (async () => {
      setLoading(true);
      setNotFound(false);
      setLoadError('');
      let publicReservation: Reservation | null = null;
      try {
        let companyId = receiptState.companyId ?? readPendingReservationPointer()?.companyId;
        let agencyId = receiptState.agencyId ?? readPendingReservationPointer()?.agencyId;

        console.log('[RECEIPT STEP]', 'reading publicReservation', id);
        const publicIdSnap = await getDoc(doc(db, 'publicReservations', id));
        if (publicIdSnap.exists()) {
          let publicData = publicIdSnap.data() as Record<string, unknown>;
          const publicToken =
            typeof publicData.token === 'string'
              ? publicData.token
              : typeof publicData.publicToken === 'string'
                ? publicData.publicToken
                : '';

          if (publicToken && publicToken !== id) {
            console.log('[RECEIPT STEP]', 'reading publicReservation token', publicToken);
            const publicTokenSnap = await getDoc(doc(db, 'publicReservations', publicToken));
            if (publicTokenSnap.exists()) {
              publicData = publicTokenSnap.data() as Record<string, unknown>;
            }
          }

          companyId = String(publicData.companyId ?? companyId ?? '');
          agencyId = String(publicData.agencyId ?? agencyId ?? '');
          if (publicData.nomClient || publicData.depart || publicData.referenceCode) {
            publicReservation = mapPublicReceiptReservation(publicData, id, companyId, agencyId);
            setReservation(publicReservation);
            setLoading(false);
          }

          const publicDocumentId = publicToken || id;
          console.log('[RECEIPT STEP]', 'subscribing publicReservation', publicDocumentId);
          unsubPublic = onSnapshot(
            doc(db, 'publicReservations', publicDocumentId),
            (snap) => {
              if (!snap.exists()) return;
              publicData = {
                ...publicData,
                ...(snap.data() as Record<string, unknown>),
              };
              const mapped = mapPublicReceiptReservation(publicData, id, companyId, agencyId);
              publicReservation = mapped;
              setReservation((current) => current ? { ...current, ...mapped } : mapped);
              setLoading(false);
            },
            (err) => {
              console.error('[ReceiptEnLignePage] publicReservation onSnapshot error:', err);
              setLoading(false);
            },
          );
        }

        if (!companyId || !agencyId) {
          setLoadError('Impossible d’afficher le reçu. Retournez à l’accueil ou ouvrez le lien billet complet.');
          setNotFound(true);
          setLoading(false);
          return;
        }

        const publicStatus = String(publicReservation?.statut ?? '');
        const publicNestedReadMayStillBeAllowed =
          publicStatus === 'en_attente' || publicStatus === 'en_attente_paiement';
        if (!auth.currentUser && publicReservation && !publicNestedReadMayStillBeAllowed) {
          return;
        }

        const resRef = reservationNestedRef(db, companyId, agencyId, publicReservation?.id ?? id);
        console.log('[RECEIPT STEP]', 'subscribing nested reservation', resRef.path);
        unsubNested = onSnapshot(resRef, (snap) => {
          if (!snap.exists()) {
            if (publicReservation) return;
            setNotFound(true);
            setReservation(null);
            setLoading(false);
            return;
          }
          const data = snap.data() as Record<string, unknown>;
          const companyId = resRef.path.split('/')[1];
          const agencyId = resRef.path.split('/')[3];
          setReservation({
            id: snap.id,
            companyId,
            agencyId,
            companySlug: (data.companySlug as string) ?? '',
            nomClient: (data.nomClient as string) ?? (data.clientNom as string) ?? '',
            telephone: getDisplayPhone(data),
            depart: (data.depart as string) ?? (data.departure as string) ?? '',
            arrivee: (data.arrivee as string) ?? (data.arrival as string) ?? '',
            date: typeof data.date === 'string' ? data.date : (data.date as any)?.seconds ? new Date((data.date as any).seconds * 1000).toISOString().slice(0, 10) : '',
            heure: (data.heure as string) ?? '',
            montant: Number(data.montant ?? data.montant_total ?? 0),
            referenceCode: data.referenceCode as string | undefined,
            statut: (data.status === 'payé' || data.status === 'paye'
              ? (data.ticketValidatedAt ? 'confirme' : 'verification')
              : data.status === 'en_attente'
                ? 'en_attente_paiement'
                : data.status === 'annulé' || data.status === 'annule'
                  ? 'annule'
                  : (data.statut as ReservationStatus | undefined)),
            canal: (data.canal as string) ?? 'en_ligne',
            seatsGo: Number(data.seatsGo ?? data.nombre_places ?? data.seats ?? 1),
            createdAt: data.createdAt,
            agencyName: (data.agencyName as string | undefined) ??
              ((data.agency as { name?: string } | undefined)?.name),
            nomAgence: data.nomAgence as string | undefined,
            agencyNom: data.agencyNom as string | undefined,
            agenceNom: data.agenceNom as string | undefined,
            modePaiement: data.modePaiement as string | undefined,
            preuveVia: data.preuveVia as string | undefined,
            remboursement: data.remboursement as { mode?: string } | undefined,
          });
          setLoading(false);
        }, (err) => {
          console.error('ReceiptEnLignePage onSnapshot error:', err);
          if (publicReservation) {
            console.warn('[ReceiptEnLignePage] keeping public receipt after nested subscription failure');
            setLoading(false);
            return;
          }
          setLoadError(!isOnline ? 'Connexion indisponible.' : 'Erreur de chargement du reçu.');
          setNotFound(true);
          setLoading(false);
        });
      } catch (err) {
        if (publicReservation) {
          console.warn('[ReceiptEnLignePage] keeping public receipt after load failure', err);
          setLoading(false);
          return;
        }
        setLoadError(
          !isOnline
            ? 'Connexion indisponible. Impossible de charger le reçu.'
            : 'Erreur de chargement du reçu. Veuillez réessayer.'
        );
        setNotFound(true);
        setLoading(false);
      }
    })();
    return () => {
      if (unsubPublic) unsubPublic();
      if (unsubNested) unsubNested();
    };
  }, [id, slug, isOnline, reloadKey, receiptState.companyId, receiptState.agencyId]);

  // Backfill caisse digitale :
  // Si la réservation est déjà en `preuve_recue`/`verification` mais qu’aucun document
  // `companies/{companyId}/payments/{reservationId}` n’existe, on crée le paiement pending online.
  useEffect(() => {
    if (!reservation?.id) return;
    if (!reservation?.companyId || !reservation?.agencyId) return;
    const s = String(reservation.statut || '').toLowerCase();
    if (!['preuve_recue', 'verification', 'verif', 'vérif'].some((k) => s.includes(k))) return;

    (async () => {
      try {
        await ensurePendingOnlinePaymentFromReservation({
          companyId: reservation.companyId,
          agencyId: String(reservation.agencyId),
          reservationId: reservation.id,
          montant: Number(reservation.montant) || 0,
          paymentMethodLabel: reservation.preuveVia ?? (reservation as any).modePaiement,
        });
      } catch (e) {
        // Backfill best-effort: on ne casse pas l’affichage du reçu.
        console.warn('[ReceiptEnLignePage] ensurePendingOnlinePaymentFromReservation failed', e);
      }
    })();
  }, [reservation]);

  /* LOAD COMPANY — sessionStorage (même id) puis Firestore ; erreur bloquante si échec */
  useEffect(() => {
    if (!reservation?.companyId) return;

    let cancelled = false;
    setCompanyLoadError('');
    setCompanyInfo(null);

    (async () => {
      try {
        const r = await loadPublicCompanyInfoSessionThenFirestore(reservation.companyId);
        if (cancelled) return;
        if (r.ok === false) {
          setCompanyLoadError(r.message);
          return;
        }
        const i = r.info;
        setCompanyInfo({
          id: i.id,
          name: i.name,
          couleurPrimaire: i.couleurPrimaire ?? i.primaryColor,
          couleurSecondaire: i.couleurSecondaire ?? i.secondaryColor,
          logoUrl: i.logoUrl,
          slug: i.slug,
          telephone: i.telephone,
        });
      } catch (e) {
        if (!cancelled) {
          setCompanyLoadError(
            e instanceof Error ? e.message : 'Erreur lors du chargement des informations de la compagnie.'
          );
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [reservation?.companyId, reloadKey]);

  /* AGENCY name + coords (for itinéraire) */
  useEffect(() => {
    const inline = resolveAgencyDisplayName(
      reservation?.agencyNom,
      reservation?.nomAgence,
      reservation?.agenceNom,
      reservation?.agencyName,
    );
    if (inline) setAgencyName(inline.toString().trim());
  }, [reservation]);

  useEffect(() => {
    const companyId = reservation?.companyId;
    const agencyId = reservation?.agencyId;
    if (!companyId || !agencyId) return;
    let cancelled = false;
    (async () => {
      try {
        const agSnap = await getDoc(doc(db, 'companies', companyId, 'agences', agencyId));
        if (cancelled) return;
        const ag = agSnap.exists() ? (agSnap.data() as any) : {};
        const resolvedAgencyName = resolveAgencyDisplayName(
          reservation?.agencyNom,
          reservation?.nomAgence,
          reservation?.agenceNom,
          reservation?.agencyName,
          ag?.nomAgence,
          ag?.nom,
          ag?.name,
        );
        const lat = ag?.latitude != null ? Number(ag.latitude) : null;
        const lng = ag?.longitude != null ? Number(ag.longitude) : null;
        if (!cancelled) {
          setAgencyName(resolvedAgencyName ? String(resolvedAgencyName).trim() : '');
          setAgencyLatitude(Number.isFinite(lat) ? lat : null);
          setAgencyLongitude(Number.isFinite(lng) ? lng : null);
        }
      } catch {}
    })();
    return () => { cancelled = true; };
  }, [
    reservation?.companyId,
    reservation?.agencyId,
    reservation?.agencyNom,
    reservation?.nomAgence,
    reservation?.agenceNom,
    reservation?.agencyName,
  ]);

  const receiptNumber = reservation?.referenceCode ?? reservation?.id ?? 'BIL-INCONNU';
  const qrValue = useMemo(() => {
    const base = window.location.origin;
    return `${base}/r/${encodeURIComponent(receiptNumber)}`;
  }, [receiptNumber]);

  const emissionDate = useMemo(() => {
    const ca = reservation?.createdAt;
    let d: Date;
    if (!ca) d = new Date();
    else if (ca instanceof Date) d = ca;
    else if (ca?.seconds) d = new Date(ca.seconds * 1000);
    else d = new Date();
    return format(d, 'dd/MM/yyyy', { locale: fr });
  }, [reservation?.createdAt]);

  const formattedDate = reservation?.date
    ? format(parseISO(reservation.date), 'dd/MM/yyyy', { locale: fr })
    : '';

  /** Libellé dynamique mode de paiement : guichet → espèces, en_ligne → preuveVia, remboursé → mode remboursement. */
  const paymentMethodDisplay = useMemo(() => {
    if (!reservation) return undefined;
    const effective = getEffectiveStatut(reservation) ?? reservation.statut;
    if (effective === 'rembourse' && reservation.remboursement?.mode) {
      const m = reservation.remboursement.mode.toLowerCase();
      if (m === 'especes' || m === 'espèces') return 'Remboursé (espèces)';
      if (m.includes('mobile') || m === 'mobile_money') return 'Remboursé (Mobile Money)';
      return `Remboursé (${reservation.remboursement.mode})`;
    }
    if ((reservation.canal ?? '').toLowerCase() === 'guichet') return reservation.modePaiement ? `Paiement ${reservation.modePaiement}` : undefined;
    return reservation.preuveVia ?? undefined;
  }, [reservation]);

  const handlePDF = useCallback(() => {
    if (!receiptRef.current) return;
    const opt = {
      margin: 2,
      filename: `recu-${receiptNumber}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: [81, 200], orientation: 'portrait' },
    };
    // @ts-ignore
    html2pdf().set(opt).from(receiptRef.current).save();
  }, [receiptNumber]);

  const handleDownloadPNG = useCallback(async () => {
    if (!receiptRef.current) return;

    await document.fonts?.ready;
    await new Promise<void>((resolve) => window.requestAnimationFrame(() => resolve()));

    const ticketElement =
      receiptRef.current.querySelector<HTMLElement>('.online-thermal-ticket') ??
      receiptRef.current;
    const ticketRect = ticketElement.getBoundingClientRect();

    const canvas = await html2canvas(ticketElement, {
      scale: 2,
      width: Math.ceil(ticketRect.width),
      height: Math.ceil(ticketRect.height),
      windowWidth: document.documentElement.clientWidth,
      windowHeight: document.documentElement.clientHeight,
      useCORS: true,
      backgroundColor: '#ffffff',
      logging: false,
    });

    canvas.toBlob((blob) => {
      if (!blob) return;
      const imageUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `billet-${receiptNumber}.png`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(imageUrl), 1000);
    }, 'image/png');
  }, [receiptNumber]);

  if (loading) {
    return (
      <div className="min-h-screen p-6 bg-gray-50">
        <div className="max-w-md mx-auto">
          <PageLoadingState />
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <h1 className="text-xl font-semibold text-gray-800 mb-2">Erreur de chargement</h1>
        <p className="text-gray-500 text-center mb-4">{loadError}</p>
        <button
          type="button"
          onClick={() => setReloadKey((v) => v + 1)}
          className="px-4 py-2 rounded-lg font-medium text-white"
          style={{ backgroundColor: primaryColor }}
        >
          Réessayer
        </button>
      </div>
    );
  }

  if (notFound || !id) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <h1 className="text-xl font-semibold text-gray-800 mb-2">Réservation introuvable</h1>
        <p className="text-gray-500 text-center mb-4">
          Ce reçu n’existe pas ou le lien est incorrect.
        </p>
        <button
          type="button"
          onClick={() => navigate(homePath)}
          className="px-4 py-2 rounded-lg font-medium text-white"
          style={{ backgroundColor: primaryColor }}
        >
          Retour à l’accueil
        </button>
      </div>
    );
  }

  if (companyLoadError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <h1 className="text-xl font-semibold text-gray-800 mb-2">Informations compagnie indisponibles</h1>
        <p className="text-gray-500 text-center mb-4 max-w-md">{companyLoadError}</p>
        <button
          type="button"
          onClick={() => setReloadKey((v) => v + 1)}
          className="px-4 py-2 rounded-lg font-medium text-white"
          style={{ backgroundColor: primaryColor }}
        >
          Réessayer
        </button>
        <button
          type="button"
          onClick={() => navigate(homePath)}
          className="mt-3 px-4 py-2 rounded-lg text-sm text-gray-600 border border-gray-200 hover:bg-gray-50"
        >
          Retour à l&apos;accueil
        </button>
      </div>
    );
  }

  if (!reservation || !companyInfo) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        Chargement du reçu...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ReservationStepHeader
        onBack={() => navigate(homePath)}
        primaryColor={primaryColor}
        secondaryColor={secondaryColor}
        title="Confirmation"
        logoUrl={companyInfo.logoUrl}
      />

      <main className="max-w-md mx-auto px-4 py-6 -mt-2">
        <div ref={receiptRef}>
          <TicketOnline
            companyName={companyInfo.name}
            logoUrl={companyInfo.logoUrl}
            primaryColor={primaryColor}
            secondaryColor={secondaryColor}
            agencyName={agencyName}
            receiptNumber={receiptNumber}
            statut={getEffectiveStatut(reservation) ?? reservation.statut}
            nomClient={reservation.nomClient}
            telephone={reservation.telephone}
            depart={reservation.depart}
            arrivee={reservation.arrivee}
            date={formattedDate}
            heure={reservation.heure}
            seats={reservation.seatsGo}
            canal={reservation.canal || 'en_ligne'}
            montant={reservation.montant}
            qrValue={qrValue}
            emissionDate={emissionDate}
            paymentMethod={paymentMethodDisplay}
            agencyLatitude={agencyLatitude}
            agencyLongitude={agencyLongitude}
          />
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t py-3 px-4 grid grid-cols-3 gap-2">
        <button
          onClick={handleDownloadPNG}
          className="py-2 rounded-lg font-medium flex items-center justify-center gap-1"
          style={{ backgroundColor: primaryColor, color: textColor }}
        >
          <Download size={16} />
          Télécharger
        </button>
        <button
          onClick={handlePDF}
          className="py-2 rounded-lg font-medium flex items-center justify-center gap-1"
          style={{ backgroundColor: secondaryColor, color: safeTextColor(secondaryColor) }}
        >
          <Printer size={16} />
          Imprimer
        </button>
        <button
          onClick={() => navigate(homePath)}
          className="py-2 rounded-lg bg-gray-200 text-gray-800 flex items-center justify-center gap-1"
        >
          <Home size={16} />
          Retour
        </button>
      </div>
    </div>
  );
};

export default ReceiptEnLignePage;
