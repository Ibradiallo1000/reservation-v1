// src/modules/compagnie/admin/layout/CompagnieLayout.tsx
// Refactored to use InternalLayout — aligned with agence (réseau, dark, F2).
import React from "react";
import { useLocation, useParams } from "react-router-dom";
import {
  Settings,
  MessageSquare,
  Gauge,
  DollarSign,
  Truck,
  TrendingUp,
  FileCheck,
  Users,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import {
  collection,
  query,
  where,
  onSnapshot,
  getDocs,
  doc,
  getDoc,
  updateDoc,
} from "firebase/firestore";
import { db } from "@/firebaseConfig";
import useCompanyTheme from "@/shared/hooks/useCompanyTheme";
import { lightenForDarkMode } from "@/utils/color";
import InternalLayout from "@/shared/layout/InternalLayout";
import type { NavSection } from "@/shared/layout/InternalLayout";
import { CurrencyProvider } from "@/shared/currency/CurrencyContext";
import { SubscriptionBanner } from "@/shared/subscription";
import type { SubscriptionStatus } from "@/shared/subscription";
import { Timestamp } from "firebase/firestore";
import { useOnlineStatus, useAgencyDarkMode, useAgencyKeyboardShortcuts, AgencyHeaderExtras } from "@/modules/agence/shared";
import { listExpenses } from "@/modules/compagnie/treasury/expenses";
import NotificationsBell from "@/modules/compagnie/notifications/NotificationsBell";
import {
  ENABLE_ADVANCED_FINANCE,
  ENABLE_FLEET,
  ENABLE_PHASE1_ONLY,
} from "@/config/featureFlags";

interface Company {
  id: string;
  nom: string;
  slug: string;
  logoUrl?: string;
  [key: string]: any;
}

/* ================= LAYOUT ================= */
const CompagnieLayout: React.FC = () => {
  const params = useParams();
  const { user, logout, company, loading, refreshUser } = useAuth();
  const isOnline = useOnlineStatus();
  const [darkMode, toggleDarkMode] = useAgencyDarkMode();

  const urlCompanyId = params.companyId;
  const userCompanyId = user?.companyId;
  const currentCompanyId = urlCompanyId || userCompanyId;

  // CEO sans companyId dans le profil : synchroniser depuis l’URL pour que les règles Firestore passent
  React.useEffect(() => {
    if (
      !user?.uid ||
      user.role !== "admin_compagnie" ||
      user.companyId ||
      !urlCompanyId
    )
      return;
    let cancelled = false;
    (async () => {
      try {
        await updateDoc(doc(db, "users", user.uid), { companyId: urlCompanyId });
        if (!cancelled) await refreshUser();
      } catch (e) {
        if (!cancelled) console.warn("CEO companyId sync:", e);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.uid, user?.role, user?.companyId, urlCompanyId, refreshUser]);

  const isImpersonationMode = Boolean(
    user?.role === "admin_platforme" && urlCompanyId,
  );

  const [currentCompany, setCurrentCompany] = React.useState<Company | null>(
    company,
  );

  // Load company from Firestore when impersonating
  React.useEffect(() => {
    if (!urlCompanyId || urlCompanyId === userCompanyId) {
      setCurrentCompany(company);
      return;
    }
    const loadCompanyFromUrl = async () => {
      try {
        const companyDoc = await getDoc(doc(db, "companies", urlCompanyId));
        if (companyDoc.exists()) {
          const data = companyDoc.data();
          setCurrentCompany({
            id: companyDoc.id,
            nom: data.nom || "",
            slug: data.slug || "",
            logoUrl: data.logoUrl,
            ...data,
          });
        }
      } catch (error) {
        console.error("Error loading company:", error);
      }
    };
    loadCompanyFromUrl();
  }, [urlCompanyId, userCompanyId, company]);

  const theme = useCompanyTheme(currentCompany);

  /* ===== BADGES ===== */
  const [onlineProofsCount, setOnlineProofsCount] = React.useState(0);
  const [pendingReviewsCount, setPendingReviewsCount] = React.useState(0);
  const [pendingCeoExpensesCount, setPendingCeoExpensesCount] = React.useState(0);

  React.useEffect(() => {
    if (!currentCompanyId) return;
    let unsubs: Array<() => void> = [];
    const countsByAgence = new Map<string, number>();

    (async () => {
      const agencesSnap = await getDocs(
        collection(db, "companies", currentCompanyId, "agences"),
      );
      agencesSnap.docs.forEach((d) => {
        const agenceId = d.id;
        const qAg = query(
          collection(
            db,
            "companies",
            currentCompanyId,
            "agences",
            agenceId,
            "reservations",
          ),
          where("statut", "==", "preuve_recue"),
        );
        const unsub = onSnapshot(qAg, (snap) => {
          countsByAgence.set(agenceId, snap.size);
          setOnlineProofsCount(
            Array.from(countsByAgence.values()).reduce((a, b) => a + b, 0),
          );
        });
        unsubs.push(unsub);
      });
    })();

    return () => unsubs.forEach((u) => u());
  }, [currentCompanyId]);

  React.useEffect(() => {
    if (!currentCompanyId) return;
    const qAvis = query(
      collection(db, "companies", currentCompanyId, "avis"),
      where("visible", "==", false),
    );
    const unsub = onSnapshot(qAvis, (snap) =>
      setPendingReviewsCount(snap.size),
    );
    return () => unsub();
  }, [currentCompanyId]);

  React.useEffect(() => {
    if (!currentCompanyId) return;
    let cancelled = false;
    const load = async () => {
      try {
        const list = await listExpenses(currentCompanyId, {
          status: "pending_ceo",
          limitCount: 300,
        });
        if (!cancelled) setPendingCeoExpensesCount(list.length);
      } catch (_) {
        if (!cancelled) setPendingCeoExpensesCount(0);
      }
    };
    void load();
    const interval = setInterval(() => void load(), 30000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [currentCompanyId]);

  const basePath = urlCompanyId
    ? `/compagnie/${urlCompanyId}`
    : "/compagnie";

  const isPlateforme = user?.role === "admin_platforme";

  const sections: NavSection[] = React.useMemo(() => {
    const all: NavSection[] = [
      // Route existante côté AppRoutes: /compagnie/:companyId/command-center
      { label: "Dashboard", icon: Gauge, path: `${basePath}/command-center` },
      {
        label: "Activité réseau",
        icon: TrendingUp,
        path: `${basePath}/reservations-reseau`,
        end: false,
        badge: onlineProofsCount,
      },
      { label: "Finances", icon: DollarSign, path: `${basePath}/finances` },
      {
        label: "Audit & contrôle",
        icon: FileCheck,
        path: `${basePath}/audit-controle`,
        badge: pendingCeoExpensesCount || undefined,
      },
      { label: "Flotte", icon: Truck, path: `${basePath}/flotte` },
      { label: "Validation chef d'agence", icon: ShieldCheck, path: `${basePath}/comptabilite/validation` },
      { label: "Clients", icon: Users, path: `${basePath}/customers` },
      {
        label: "Avis clients",
        icon: MessageSquare,
        path: `${basePath}/avis-clients`,
        badge: pendingReviewsCount,
      },
      { label: "Configuration", icon: Settings, path: `${basePath}/parametres` },
    ];
    const phase1Filtered = ENABLE_PHASE1_ONLY
      ? all.filter((s) => {
          if (!ENABLE_ADVANCED_FINANCE && s.label === "Audit & contrôle") return false;
          if (!ENABLE_FLEET && s.label === "Flotte") return false;
          return true;
        })
      : all;
    if (isPlateforme) return phase1Filtered;
    return phase1Filtered
      .filter(
        (s) =>
          !["Validation chef d'agence", "Clients", "Avis clients"].includes(s.label),
      )
      .map((s) =>
        s.label === "Audit & contrôle" ? { ...s, label: "Alertes" } : s,
      );
  }, [
    basePath,
    isPlateforme,
    onlineProofsCount,
    pendingCeoExpensesCount,
    pendingReviewsCount,
  ]);

  useAgencyKeyboardShortcuts(sections);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div
            className="w-12 h-12 border-4 border-t-transparent rounded-full animate-spin mx-auto mb-4"
            style={{ borderColor: `${theme.colors.primary} transparent transparent transparent` }}
          />
          <p className="text-sm text-gray-500">Chargement...</p>
        </div>
      </div>
    );
  }

  // Subscription status from company data
  const subStatus = (currentCompany as any)?.subscriptionStatus as SubscriptionStatus | undefined;
  const trialEndsAtRaw = (currentCompany as any)?.trialEndsAt;
  const trialEndsAt = trialEndsAtRaw instanceof Timestamp
    ? trialEndsAtRaw.toDate()
    : trialEndsAtRaw instanceof Date
      ? trialEndsAtRaw
      : null;

  const bannerContent = (
    <>
      {isImpersonationMode && (
        <div className="bg-yellow-50 border-b border-yellow-200 px-6 py-2">
          <div className="flex items-center justify-between max-w-7xl mx-auto">
            <span className="text-sm text-yellow-800">
              Mode inspection : <strong>{currentCompany?.nom}</strong>
            </span>
            <button
              onClick={() => (window.location.href = "/admin/compagnies")}
              className="text-sm bg-yellow-600 text-white px-3 py-1 rounded-lg hover:bg-yellow-700 transition"
            >
              Retour admin
            </button>
          </div>
        </div>
      )}
      <SubscriptionBanner
        subscriptionStatus={subStatus}
        trialEndsAt={trialEndsAt}
        companyName={currentCompany?.nom}
      />
    </>
  );

  // Valeurs par défaut alignées : orange / blanc
  const primary = (theme?.colors?.primary ?? "#FF6600").trim();
  const secondary = (theme?.colors?.secondary ?? "#FFFFFF").trim();
  const cssVars = React.useMemo(() => {
    if (darkMode) {
      return {
        "--teliya-primary": lightenForDarkMode(primary),
        "--teliya-secondary": lightenForDarkMode(secondary),
      } as React.CSSProperties;
    }
    return {
      "--teliya-primary": primary,
      "--teliya-secondary": secondary,
    } as React.CSSProperties;
  }, [darkMode, primary, secondary]);

  return (
    <CurrencyProvider currency={(currentCompany as any)?.devise}>
      <div className={darkMode ? "agency-dark" : ""} style={cssVars}>
        <InternalLayout
          sections={sections}
          role={(user as any)?.role || "admin_compagnie"}
          userName={user?.displayName || undefined}
          userEmail={user?.email || undefined}
          brandName={currentCompany?.nom || "Compagnie"}
          logoUrl={currentCompany?.logoUrl}
          primaryColor={theme.colors.primary}
          secondaryColor={theme.colors.secondary}
          onLogout={logout}
          banner={bannerContent}
          headerRight={
            <div className="flex items-center gap-2">
              <NotificationsBell
                companyId={currentCompanyId}
                userId={user?.uid}
                role={user?.role}
              />
              <AgencyHeaderExtras isOnline={isOnline} darkMode={darkMode} onDarkModeToggle={toggleDarkMode} showThemeToggle={false} />
            </div>
          }
          mainClassName="agency-content-transition"
        />
      </div>
    </CurrencyProvider>
  );
};

export default CompagnieLayout;
