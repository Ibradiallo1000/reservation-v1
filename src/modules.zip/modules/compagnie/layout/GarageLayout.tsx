// src/modules/compagnie/layout/GarageLayout.tsx
// Layout dédié Chef Garage : uniquement Flotte + Configuration (pas d’accès CEO).
import React from "react";
import { useParams } from "react-router-dom";
import { LayoutDashboard, List, Wrench, MapPin, AlertTriangle, Moon, Sun, Package, ShieldAlert, Users, Route } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { doc, getDoc, updateDoc, collection, query, where, onSnapshot, getDocs } from "firebase/firestore";
import { db } from "@/firebaseConfig";
import InternalLayout from "@/shared/layout/InternalLayout";
import type { NavSection } from "@/shared/layout/InternalLayout";
import {
  ENABLE_FLEET,
  ENABLE_LOGISTICS,
  ENABLE_PHASE1_ONLY,
} from "@/config/featureFlags";
import { CurrencyProvider } from "@/shared/currency/CurrencyContext";
import useCompanyTheme from "@/shared/hooks/useCompanyTheme";
import type { Company } from "@/types/companyTypes";
import { useAgencyDarkMode } from "@/modules/agence/shared";
import { GarageThemeProvider } from "./GarageThemeContext";

const GarageLayout: React.FC = () => {
  const params = useParams();
  const { user, logout, company, loading, refreshUser } = useAuth();
  const urlCompanyId = params.companyId;
  const userCompanyId = user?.companyId;
  const currentCompanyId = urlCompanyId || userCompanyId;

  const [syncingCompanyId, setSyncingCompanyId] = React.useState(false);
  const role = String(user?.role ?? "");
  const isGarageOrCeo = role === "admin_compagnie" || role === "responsable_logistique" || role === "chef_garage";
  const needsCompanyIdSync = Boolean(user?.uid && isGarageOrCeo && !user.companyId && urlCompanyId);

  // Sans companyId : synchroniser depuis l’URL pour que les règles Firestore passent (CEO + responsable_logistique)
  React.useEffect(() => {
    if (!needsCompanyIdSync) return;
    let cancelled = false;
    setSyncingCompanyId(true);
    (async () => {
      try {
        await updateDoc(doc(db, "users", user!.uid), { companyId: urlCompanyId });
        if (!cancelled) await refreshUser();
      } catch (e) {
        if (!cancelled) console.warn("Garage companyId sync:", e);
      } finally {
        if (!cancelled) setSyncingCompanyId(false);
      }
    })();
    return () => { cancelled = true; };
  }, [needsCompanyIdSync, user?.uid, urlCompanyId, refreshUser]);

  const [currentCompany, setCurrentCompany] = React.useState<Company | null>(
    (company ?? null) as Company | null
  );

  const [darkMode, toggleDarkMode] = useAgencyDarkMode();
  const [pendingPlanningCount, setPendingPlanningCount] = React.useState(0);
  const [pendingLogisticsActionsCount, setPendingLogisticsActionsCount] = React.useState(0);

  React.useEffect(() => {
    if (darkMode) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
    return () => document.documentElement.classList.remove("dark");
  }, [darkMode]);

  const theme = useCompanyTheme(currentCompany);
  const garageTheme = React.useMemo(
    () => ({
      primary: theme?.primary ?? "#475569",
      secondary: theme?.secondary ?? "#64748b",
      primaryDark: theme?.primaryDark,
      primaryLight: theme?.primaryLight,
      buttonText: (theme as any)?.colors?.buttonText ?? "#ffffff",
    }),
    [theme]
  );

  React.useEffect(() => {
    if (!urlCompanyId || urlCompanyId === userCompanyId) {
      setCurrentCompany(company as Company | null);
      return;
    }
    const loadCompanyFromUrl = async () => {
      try {
        const companyDoc = await getDoc(doc(db, "companies", urlCompanyId));
        if (companyDoc.exists()) {
          const data = companyDoc.data() as Record<string, unknown>;
          setCurrentCompany({
            id: companyDoc.id,
            nom: (data.nom as string) || "",
            slug: (data.slug as string) ?? "",
            logoUrl: data.logoUrl as string | undefined,
            ...data,
          } as Company);
        }
      } catch (error) {
        console.error("Error loading company:", error);
      }
    };
    loadCompanyFromUrl();
  }, [urlCompanyId, userCompanyId, company]);

  React.useEffect(() => {
    if (!currentCompanyId) {
      setPendingPlanningCount(0);
      return;
    }
    const unsubs: Array<() => void> = [];
    const countsByAgency = new Map<string, number>();
    let cancelled = false;

    (async () => {
      try {
        const agencesSnap = await getDocs(collection(db, "companies", currentCompanyId, "agences"));
        if (cancelled) return;
        agencesSnap.docs.forEach((ag) => {
          const agencyId = ag.id;
          const q = query(
            collection(db, "companies", currentCompanyId, "agences", agencyId, "tripAssignments"),
            where("status", "==", "planned")
          );
          const unsub = onSnapshot(
            q,
            (snap) => {
              countsByAgency.set(agencyId, snap.size);
              setPendingPlanningCount(Array.from(countsByAgency.values()).reduce((sum, n) => sum + n, 0));
            },
            () => {
              countsByAgency.set(agencyId, 0);
              setPendingPlanningCount(Array.from(countsByAgency.values()).reduce((sum, n) => sum + n, 0));
            }
          );
          unsubs.push(unsub);
        });
      } catch {
        setPendingPlanningCount(0);
      }
    })();

    return () => {
      cancelled = true;
      unsubs.forEach((u) => u());
    };
  }, [currentCompanyId]);

  React.useEffect(() => {
    if (!currentCompanyId) {
      setPendingLogisticsActionsCount(0);
      return;
    }
    const q = query(
      collection(db, "companies", currentCompanyId, "logisticsActions"),
      where("status", "==", "pending")
    );
    const unsub = onSnapshot(
      q,
      (snap) => setPendingLogisticsActionsCount(snap.size),
      () => setPendingLogisticsActionsCount(0)
    );
    return () => unsub();
  }, [currentCompanyId]);

  const basePath = urlCompanyId
    ? `/compagnie/${urlCompanyId}/garage`
    : "/compagnie/garage";

  const globalLogisticsBadge = pendingPlanningCount + pendingLogisticsActionsCount;
  const allSections: NavSection[] = [
    { label: "Tableau de bord", icon: LayoutDashboard, path: `${basePath}/dashboard`, end: true },
    { label: "Routes réseau", icon: Route, path: `${basePath}/routes`, end: true },
    { label: "Logistique", icon: Package, path: `${basePath}/logistics`, end: true, badge: globalLogisticsBadge || undefined },
    { label: "Équipage", icon: Users, path: `${basePath}/logistics/crew`, end: true },
    { label: "Liste flotte", icon: List, path: `${basePath}/fleet`, end: true },
    { label: "Maintenance", icon: Wrench, path: `${basePath}/maintenance`, end: true },
    { label: "Transit", icon: MapPin, path: `${basePath}/transit`, end: true },
    { label: "Incidents", icon: AlertTriangle, path: `${basePath}/incidents`, end: true },
    { label: "Conformité bus", icon: ShieldAlert, path: `${basePath}/logistics/compliance`, end: true },
    { label: "Urgence trajet", icon: AlertTriangle, path: `${basePath}/logistics/emergency`, end: true },
  ];
  const sections: NavSection[] = ENABLE_PHASE1_ONLY
    ? allSections.filter((s) => {
        if (!ENABLE_FLEET && ["Liste flotte", "Maintenance", "Transit", "Incidents"].includes(s.label)) return false;
        if (!ENABLE_LOGISTICS && ["Logistique", "Équipage", "Conformité bus", "Urgence trajet"].includes(s.label)) return false;
        return s.label === "Routes réseau" && ENABLE_FLEET;
      })
    : allSections;

  const headerRight = (
    <button
      type="button"
      onClick={toggleDarkMode}
      className="p-2 rounded-lg transition text-xs bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200"
      title={darkMode ? "Mode jour" : "Mode nuit"}
    >
      {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
    </button>
  );

  if (loading || (needsCompanyIdSync && syncingCompanyId)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-slate-300 border-t-slate-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm text-slate-600">{syncingCompanyId ? "Configuration de l’accès…" : "Chargement..."}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={darkMode ? "agency-dark" : ""}>
      <CurrencyProvider currency={(currentCompany as any)?.devise}>
        <GarageThemeProvider value={garageTheme}>
          <InternalLayout
            sections={sections}
            role={(user as any)?.role || "responsable_logistique"}
            userName={user?.displayName || undefined}
            userEmail={user?.email || undefined}
            brandName={currentCompany?.nom || "Garage"}
            logoUrl={currentCompany?.logoUrl}
            primaryColor={garageTheme.primary}
            secondaryColor={garageTheme.secondary}
            onLogout={logout}
            mainClassName="garage-content"
            headerRight={headerRight}
          />
        </GarageThemeProvider>
      </CurrencyProvider>
    </div>
  );
};

export default GarageLayout;
