export { default } from "./ManagerExpensesPage";
