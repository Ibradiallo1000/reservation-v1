import {
  doc,
  getDoc,
  runTransaction,
  serverTimestamp,
  collection,
  arrayUnion,
} from "firebase/firestore";
import { db } from "@/firebaseConfig";
import { canonicalStatut, isValidTransition } from "@/utils/reservationStatusUtils";
import { buildStatutTransitionPayload } from "@/modules/agence/services/reservationStatutService";
import {
  releaseSeatsOnTripInstanceInTransaction,
  tripInstanceRef,
} from "@/modules/compagnie/tripInstances/tripInstanceService";

/** Champs éditables par le guichet */
export type ReservationEditable = Partial<{
  clientNom: string;
  telephone: string;
  email: string | null;
  date: string;           // YYYY-MM-DD
  heure: string;          // HH:mm
  depart: string;
  arrivee: string;
  seatsGo: number;
  seatsReturn: number;
  montant: number;        // autorisé si tu veux recalculer
}>;

export type CancelOptions = {
  reason?: string;
  requestedByUid: string;
  requestedByName?: string | null;
  requestedByRole?: string;
};

export type ModifyOptions = {
  patch: ReservationEditable;
  requestedByUid: string;
  requestedByName?: string | null;
};

/** Annuler un billet (statut → "annule", canonique). Phase B : transition + auditLog obligatoire. Libère les places sur le tripInstance si présent. */
export async function cancelReservation(
  companyId: string,
  agencyId: string,
  reservationId: string,
  { reason, requestedByUid, requestedByName, requestedByRole }: CancelOptions
) {
  const base = `companies/${companyId}/agences/${agencyId}`;
  const ref = doc(db, `${base}/reservations/${reservationId}`);

  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error("Réservation introuvable.");
    const data = snap.data() as Record<string, unknown>;
    const oldStatut = String(data.statut ?? "");

    if (canonicalStatut(oldStatut) === "annule") return;

    if (!isValidTransition(oldStatut, "annule")) {
      throw new Error(`Transition non autorisée vers annule depuis: ${oldStatut}`);
    }

    const tripInstanceId = (data.tripInstanceId as string | null) ?? null;
    const seatsToRelease =
      Number(data.seatsGo ?? 0) + Number(data.seatsReturn ?? 0);

    const auditEntry = buildStatutTransitionPayload(oldStatut, "annule", {
      userId: requestedByUid,
      userRole: requestedByRole ?? "chefAgence",
    });

    tx.update(ref, {
      statut: "annule",
      updatedAt: serverTimestamp(),
      cancelledAt: serverTimestamp(),
      cancelledBy: requestedByUid,
      cancelledByName: requestedByName || null,
      cancelReason: reason || "",
      statutEmbarquement: "en_attente",
      reportInfo: null,
      checkInTime: null,
      auditLog: arrayUnion(auditEntry),
    });

    const logRef = doc(collection(db, `${base}/reservationLogs`));
    tx.set(logRef, {
      type: "CANCEL",
      reservationId,
      prev: { statut: data.statut },
      next: { statut: "annule" },
      reason: reason || "",
      by: { uid: requestedByUid, name: requestedByName || null },
      createdAt: serverTimestamp(),
    });

    if (tripInstanceId && seatsToRelease > 0) {
      const tiRef = tripInstanceRef(companyId, tripInstanceId);
      const tiSnap = await tx.get(tiRef);
      releaseSeatsOnTripInstanceInTransaction(tx, tiRef, tiSnap, seatsToRelease, {
        originStopOrder: data.originStopOrder as number | null | undefined,
        destinationStopOrder: data.destinationStopOrder as number | null | undefined,
        depart: String(data.depart ?? ""),
        arrivee: String(data.arrivee ?? ""),
      });
    }
  });
}

/** Modifier un billet (patch partiel et audité). */
export async function modifyReservation(
  companyId: string,
  agencyId: string,
  reservationId: string,
  { patch, requestedByUid, requestedByName }: ModifyOptions
) {
  const base = `companies/${companyId}/agences/${agencyId}`;
  const ref = doc(db, `${base}/reservations/${reservationId}`);

  // Nettoyage des champs vides / coercition minimale
  const safePatch: any = {};
  const allowKeys: (keyof ReservationEditable)[] = [
    "clientNom","telephone","email","date","heure","depart","arrivee","seatsGo","seatsReturn","montant",
  ];
  for (const k of allowKeys) {
    if (patch[k] !== undefined) safePatch[k] = patch[k];
  }

  // Exemple : normaliser téléphone / quantités
  if (safePatch.telephone) {
    safePatch.telephone = String(safePatch.telephone).replace(/\D/g, "");
  }
  if (safePatch.seatsGo !== undefined) {
    safePatch.seatsGo = Math.max(0, Number(safePatch.seatsGo || 0));
  }
  if (safePatch.seatsReturn !== undefined) {
    safePatch.seatsReturn = Math.max(0, Number(safePatch.seatsReturn || 0));
  }

  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error("Réservation introuvable.");
    const prev = snap.data() as any;

    // Exemple de restrictions : interdire de modifier un billet annulé
    if (canonicalStatut(prev.statut) === "annule") {
      throw new Error("Billet déjà annulé.");
    }

    // Si tu veux interdire changement de trajet si déjà embarqué
    if (prev.statutEmbarquement === "embarqué" || prev.statutEmbarquement === "embarque") {
      const fieldsThatChangeTrip = ["date","heure","depart","arrivee","seatsGo","seatsReturn"];
      if (fieldsThatChangeTrip.some(f => safePatch[f] !== undefined)) {
        throw new Error("Impossible de modifier le trajet après embarquement.");
      }
    }

    // Patch
    const next = {
      ...safePatch,
      updatedAt: serverTimestamp(),
      modifiedBy: requestedByUid,
      modifiedByName: requestedByName || null,
      // Si tu modifies date/heure/dep/arr, pense à maintenir 'trajetId' si tu relies par ID
      // Ici, on laisse tel quel. Tu peux recalculer/poser un nouvel ID si nécessaire.
    };

    tx.update(ref, next);

    const logRef = doc(collection(db, `${base}/reservationLogs`));
    tx.set(logRef, {
      type: "MODIFY",
      reservationId,
      patch: safePatch,
      by: { uid: requestedByUid, name: requestedByName || null },
      prevSnapshot: {
        date: prev.date,
        heure: prev.heure,
        depart: prev.depart,
        arrivee: prev.arrivee,
        clientNom: prev.clientNom,
        telephone: prev.telephone,
        seatsGo: prev.seatsGo,
        seatsReturn: prev.seatsReturn,
        montant: prev.montant,
        statut: prev.statut,
        statutEmbarquement: prev.statutEmbarquement,
      },
      createdAt: serverTimestamp(),
    });
  });
}
