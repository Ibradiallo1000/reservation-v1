// src/components/ReceiptModal.tsx

import React, { useRef } from 'react';
import QRCode from 'react-qr-code';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import html2pdf from 'html2pdf.js';
import { SALE_PENDING_UI_STATUT, SALE_SLOW_UI_STATUT, SALE_ERROR_UI_STATUT } from '@/modules/agence/guichet/components/pos/RecentSales';
import { useFormatCurrency } from '@/shared/currency/CurrencyContext';

export interface ReservationData {
  id: string;
  nomClient: string;
  telephone: string;
  date: string;
  heure: string;
  depart: string;
  arrivee: string;
  seatsGo: number;
  seatsReturn?: number;
  montant: number;

  paiement?: string;
  statut?: string;
  referenceCode?: string;

  agencyNom?: string;
  agenceTelephone?: string;
  createdAt?: any;

  compagnieId?: string | null;
  agencyId?: string | null;
  companySlug?: string | null;

  guichetierId?: string | null;
  guichetierCode?: string | null;

  shiftId?: string | null;
  email?: string | null;
}

export interface CompanyData {
  nom: string;
  logoUrl?: string;
  telephone?: string;
  couleurPrimaire?: string;   // ✅ AJOUTÉ
  couleurSecondaire?: string; // ✅ AJOUTÉ
  slug?: string;
  id?: string;
}

type Props = {
  open: boolean;
  onClose: () => void;
  reservation: ReservationData;
  company: CompanyData;
};

/* 🔥 Capitalisation automatique nom/prénom */
function formatFullName(name: string) {
  return name
    ?.toLowerCase()
    .split(' ')
    .filter(Boolean)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

/* 🔥 Format date JJ/MM/AAAA */
function formatTripDate(dateStr: string) {
  try {
    return format(new Date(dateStr), 'dd/MM/yyyy', { locale: fr });
  } catch {
    return dateStr;
  }
}

const ReceiptModal: React.FC<Props> = ({
  open,
  onClose,
  reservation,
  company
}) => {
  const money = useFormatCurrency();
  const ref = useRef<HTMLDivElement>(null);

  if (!open) return null;

  const receiptNumber =
    reservation.referenceCode || reservation.id;

  const qrValue = `${window.location.origin}/r/${receiptNumber}`;

  const emissionDate = format(
    new Date(reservation.createdAt || new Date()),
    'dd/MM/yyyy HH:mm',
    { locale: fr }
  );

  const isPendingEncaissement = reservation.statut === SALE_PENDING_UI_STATUT;
  const isErrorEncaissement = reservation.statut === SALE_ERROR_UI_STATUT;
  const blockFinalTicket =
    isPendingEncaissement || reservation.statut === SALE_SLOW_UI_STATUT || isErrorEncaissement;

  const handlePDF = () => {
    if (!ref.current) return;
    if (blockFinalTicket) return;

    html2pdf()
      .set({
        margin: 2,
        filename: `ticket-${receiptNumber}.pdf`,
        html2canvas: { scale: 2, backgroundColor: '#ffffff' },
        jsPDF: { unit: 'mm', format: [80, 200] }
      })
      .from(ref.current)
      .save();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-x-hidden overflow-y-auto bg-black/40 p-2 sm:p-4">

      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #thermal-ticket, #thermal-ticket * { visibility: visible !important; }
          #thermal-ticket {
            position: absolute;
            left: 0;
            top: 0;
            width: 80mm !important;
            max-width: 80mm !important;
            background: #fff !important;
            color: #111 !important;
            box-shadow: none !important;
          }
          .no-print { display: none !important; }
        }
      `}</style>

      <div
        id="thermal-ticket"
        className="ticket-force-light my-auto max-h-[calc(100dvh-1rem)] max-w-full shrink-0 overflow-x-hidden overflow-y-auto rounded-xl bg-white text-black shadow-xl sm:max-h-[calc(100dvh-2rem)]"
        style={{
          width: '80mm',
          fontFamily: 'monospace',
          fontSize: '12px',
          lineHeight: '1.5'
        }}
      >

        {/* HEADER ACTIONS */}
        <div className="no-print sticky top-0 z-10 flex flex-col items-center gap-2 border-b bg-white px-3 py-3">
          <div className="w-full min-w-0 truncate text-center font-semibold">{company.nom}</div>
          <div className="grid w-full grid-cols-3 gap-1.5 text-xs">
            <button className="flex min-h-10 items-center justify-center rounded-lg border border-gray-200 px-1.5" type="button" onClick={handlePDF} disabled={blockFinalTicket} title={blockFinalTicket ? "Disponible après validation" : undefined}>
              PDF
            </button>
            <button
              className="flex min-h-10 items-center justify-center rounded-lg border border-gray-200 px-1.5"
              type="button"
              onClick={() => window.print()}
              disabled={blockFinalTicket}
              title={blockFinalTicket ? "Disponible après validation" : undefined}
            >
              Imprimer
            </button>
            <button className="flex min-h-10 items-center justify-center rounded-lg border border-gray-200 px-1.5" type="button" onClick={onClose}>Fermer</button>
          </div>
        </div>

        {/* CONTENU */}
        <div ref={ref} className="bg-white p-4 text-black">

          {/* LOGO + NOM */}
          <div className="text-center mb-3">
            {company.logoUrl && (
              <img
                src={company.logoUrl}
                alt="logo"
                style={{
                  width: '60px',
                  height: '60px',
                  objectFit: 'cover',
                  borderRadius: '50%',
                  border: '2px solid #000',
                  margin: '0 auto'
                }}
              />
            )}

            <div style={{ fontWeight: 'bold', fontSize: '14px', marginTop: '6px' }}>
              {company.nom.toUpperCase()}
            </div>

            <div style={{ fontSize: '11px' }}>
              {reservation.agencyNom || 'Agence'}
            </div>
          </div>

          <hr />

          {/* RÉFÉRENCE */}
          <div style={{ textAlign: 'center', margin: '6px 0' }}>
            <div style={{ fontWeight: 'bold' }}>
              N° {receiptNumber}
            </div>
            <div style={{ fontSize: '11px' }}>
              Émis le {emissionDate}
            </div>
            <div style={{ fontSize: '11px', marginTop: '4px' }}>
              Guichetier : <strong>{reservation.guichetierCode || 'GUEST'}</strong>
            </div>
          </div>

          <hr />

          {/* PASSAGER ALIGNÉ */}
          <div style={{ marginTop: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Passager :</span>
              <span style={{ fontWeight: 'bold' }}>
                {formatFullName(reservation.nomClient)}
              </span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Téléphone :</span>
              <span>{reservation.telephone}</span>
            </div>
          </div>

          <hr />

          {/* TRAJET */}
          <div style={{ textAlign: 'center', margin: '10px 0' }}>
            <div style={{
              fontWeight: 'bold',
              fontSize: '14px',
              letterSpacing: '1px'
            }}>
              {reservation.depart.toUpperCase()} → {reservation.arrivee.toUpperCase()}
            </div>

            <div style={{ marginTop: '4px' }}>
              {formatTripDate(reservation.date)} • {reservation.heure}
            </div>

            <div style={{ fontSize: '11px' }}>
              {reservation.seatsGo} billet • guichet
            </div>
          </div>

          <hr />

          {/* MONTANT */}
          <div style={{ textAlign: 'center', margin: '10px 0' }}>
            <div style={{
              fontSize: '16px',
              fontWeight: 'bold'
            }}>
              {money(reservation.montant)}
            </div>

            <div style={{ fontSize: '11px' }}>
              Paiement : {(reservation.paiement || 'espèces').toUpperCase()}
            </div>
          </div>

          <hr />

          {blockFinalTicket ? (
            isErrorEncaissement ? (
              <div
                className="no-print rounded-lg border border-red-300 bg-red-50 px-3 py-2.5 text-center text-red-900"
                style={{ marginTop: '12px', fontSize: '11px', lineHeight: 1.45 }}
              >
                <strong>Encaissement en erreur</strong>
                <br />
                La transaction n&apos;a pas été validée. Veuillez relancer l&apos;encaissement.
              </div>
            ) : null
          ) : (
            <>
              {/* QR — masqué tant que la transaction Firestore n’a pas réussi */}
              <div
                style={{
                  marginTop: '12px',
                  display: 'flex',
                  justifyContent: 'center'
                }}
              >
                <QRCode value={qrValue} size={100} level="H" fgColor="#000000" />
              </div>

              <div
                style={{
                  textAlign: 'center',
                  fontSize: '10px',
                  marginTop: '6px'
                }}
              >
                Validité : 1 mois à compter de la date d’émission.
              </div>
            </>
          )}

          <hr />

          {/* FOOTER */}
          <div style={{
            textAlign: 'center',
            fontSize: '10px',
            marginTop: '8px'
          }}>

            <div>
              Merci d'avoir choisi {company.nom}
            </div>
         </div>
        </div>
      </div>
    </div>
  );
};

export default ReceiptModal;
